"""Local, repeatable file/geometry checks. NOT a Unity, Blender or Autodesk import test.
Run from any directory: python Validation/validate_pack.py
Requires numpy, Pillow, trimesh and PyYAML. Reports clearly distinguish pending external checks.
"""
from __future__ import annotations
import collections, hashlib, io, json, math, re, struct, sys, tarfile, zlib
from pathlib import Path
import numpy as np
from PIL import Image
import trimesh
import yaml
ROOT=Path(__file__).resolve().parent.parent
ASSET=ROOT/'UnityProject/Assets/ConstructionSiteEssentials'
DATA=json.loads((ROOT/'Source/mesh_data.json').read_text())
R=np.array([[1,0,0],[0,0,1],[0,-1,0]],float)
REPORT={'pack':'Construction Site Essentials','version':'1.0.0','checks':[], 'props':[], 'pending':[
'Execute build_blender.py in Blender 4.2+; inspect and save the .blend file.',
'Import FBX files in an independent DCC or Unity Editor. The local FBX check is structural only.',
'Compile the supplied Editor C# in Unity; rebind prefabs with Setup for Active Pipeline.',
'Test URP and Built-In separately in real Unity projects; inspect materials, axes, scale and colliders.',
'Open/rebuild the Unity demo; check visual quality, lightmap baking and target-device performance.',
'Run the current Unity Asset Store publishing validator and complete publisher/legal/AI review.',
'Run the Khronos glTF Validator (not installed here); local GLB checks and independent Trimesh loading are not that validator.'
]}

def check(name,condition,detail=''):
    REPORT['checks'].append({'check':name,'status':'PASS' if condition else 'FAIL','detail':str(detail)})
    if not condition:print('FAIL',name,detail,flush=True)

def decode_fbx(path):
    data=path.read_bytes();assert data[:23]==b'Kaydara FBX Binary  \x00\x1a\x00';assert struct.unpack_from('<I',data,23)[0]==7400
    def prop(offset):
        kind=chr(data[offset]);offset+=1
        scalars={'Y':'h','C':'?','I':'i','F':'f','D':'d','L':'q'}
        if kind in scalars:
            fmt='<'+scalars[kind];val=struct.unpack_from(fmt,data,offset)[0];return val,offset+struct.calcsize(fmt)
        if kind in ['S','R']:
            size=struct.unpack_from('<I',data,offset)[0];offset+=4;assert offset+size<=len(data);val=data[offset:offset+size]
            return (val.decode('utf8') if kind=='S' else val),offset+size
        assert kind in 'fdilb',kind
        count,encoding,size=struct.unpack_from('<III',data,offset);offset+=12;assert encoding in [0,1];raw=data[offset:offset+size];assert len(raw)==size
        if encoding:raw=zlib.decompress(raw)
        dtype={'f':'<f4','d':'<f8','i':'<i4','l':'<i8','b':'u1'}[kind];values=np.frombuffer(raw,dtype=dtype);assert len(values)==count
        return values,offset+size
    def node(offset,parent_end):
        end,count,plen,nlen=struct.unpack_from('<IIIB',data,offset)
        if end==0:assert data[offset:offset+13]==b'\0'*13;return None,offset+13
        assert offset<end<=parent_end<=len(data);start=offset+13;name=data[start:start+nlen].decode('utf8');start+=nlen;props=[];cursor=start
        for _ in range(count):value,cursor=prop(cursor);props.append(value)
        assert cursor==start+plen;children=[]
        while cursor<end:
            child,cursor=node(cursor,end)
            if child is None:assert cursor==end;break
            children.append(child)
        assert cursor==end
        return {'name':name,'props':props,'children':children},end
    nodes=[];offset=27
    while True:
        n,offset=node(offset,len(data))
        if n is None:break
        nodes.append(n)
    assert len(data)-offset>=144
    return nodes

def child(node,name):return next(x for x in node['children'] if x['name']==name)
def top(nodes,name):return next(x for x in nodes if x['name']==name)
def walk(node):
    yield node
    for c in node['children']:yield from walk(c)

def glb_read(path):
    data=path.read_bytes();magic,version,size=struct.unpack_from('<4sII',data);assert magic==b'glTF' and version==2 and size==len(data)
    offset=12;chunks=[]
    while offset<len(data):
        length,kind=struct.unpack_from('<I4s',data,offset);offset+=8;assert length%4==0 and offset+length<=len(data);chunks.append((kind,data[offset:offset+length]));offset+=length
    assert chunks[0][0]==b'JSON' and chunks[1][0]==b'BIN\0' and len(chunks)==2
    doc=json.loads(chunks[0][1]);blob=chunks[1][1];assert doc['asset']['version']=='2.0';assert doc['buffers'][0]['byteLength']<=len(blob)
    for view in doc['bufferViews']:assert view.get('byteOffset',0)+view['byteLength']<=len(blob)
    def access(ix):
        a=doc['accessors'][ix];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        start=v.get('byteOffset',0)+a.get('byteOffset',0);count=a['count']*width;end=start+count*np.dtype(dtype).itemsize;assert end<=v.get('byteOffset',0)+v['byteLength']
        return np.frombuffer(blob,dtype=dtype,count=count,offset=start).reshape(a['count'],width)
    for image in doc.get('images',[]):
        assert 'uri' not in image and image['mimeType']=='image/png';v=doc['bufferViews'][image['bufferView']];raw=blob[v['byteOffset']:v['byteOffset']+v['byteLength']]
        im=Image.open(io.BytesIO(raw));im.verify()
    return doc,access

def validate_geometry(p):
    name=p['name'];v=np.array(p['vertices']);n=np.array(p['normals']);uv0=np.array(p['uv0']);uv1=np.array(p['uv1']);t=np.array(p['triangles']);tm=np.array(p['tri_material']);s=p['stats']
    assert all(np.isfinite(x).all() for x in [v,n,uv0,uv1]);assert t.min()>=0 and t.max()<len(v)
    cross=np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]]);area=np.linalg.norm(cross,axis=1)*.5
    check(name+'/finite_geometry_and_index_bounds',True)
    check(name+'/no_degenerate_triangles',area.min()>1e-12,'minimum area m2 = %.10g'%area.min())
    check(name+'/consistent_normals',np.max(abs(np.linalg.norm(n,axis=1)-1))<1e-5 and np.all(np.einsum('ij,ij->i',cross,n[t].mean(1))>=-1e-12))
    check(name+'/ground_pivot',abs(v[:,2].min())<1e-6 and max(abs((v.max(0)+v.min(0))[:2]/2))<1e-6)
    check(name+'/triangle_and_material_counts',len(t)==s['triangles'] and len(tm)==len(t) and len(p['materials'])==s['material_slots'] and tm.max()<len(p['materials']))
    check(name+'/two_complete_uv_channels',len(uv0)==len(v) and len(uv1)==len(v))
    check(name+'/uv1_inside_unit_square',uv1.min()>=0 and uv1.max()<=1)
    ut=uv1[t];e0=ut[:,1]-ut[:,0];e1=ut[:,2]-ut[:,0];crossuv=e0[:,0]*e1[:,1]-e0[:,1]*e1[:,0];check(name+'/uv1_non_degenerate',np.min(abs(crossuv))>1e-14)
    # Every source face owns one chart; bounding rectangles are stricter than polygon overlap.
    boxes=np.array([[*uv1[f].min(0),*uv1[f].max(0)] for f in p['faces']]);order=np.argsort(boxes[:,0]);active=[];overlaps=0;min_gap=1.
    for ix in order:
        box=boxes[ix];active=[j for j in active if boxes[j,2]>box[0]+1e-8]
        for j in active:
            other=boxes[j]
            if min(other[3],box[3])-max(other[1],box[1])>1e-8:overlaps+=1
        active.append(ix)
    check(name+'/uv1_charts_do_not_overlap',overlaps==0,f'{len(boxes)} source-face charts; UV0 intentionally repeats')
    # Check closed component orientation. Decal planes are intentionally open.
    open_parts=[];negative_volumes=[]
    for part in p['source']:
        vertices=np.asarray(part['vertices']);faces=[];edges=collections.Counter()
        for face in part['faces']:
            for i in range(len(face)):edges[tuple(sorted([face[i],face[(i+1)%len(face)]]))]+=1
            for i in range(1,len(face)-1):faces.append([face[0],face[i],face[i+1]])
        closed=all(count==2 for count in edges.values())
        if not closed:open_parts.append(part['name']);continue
        a=vertices[np.array(faces)];volume=np.sum(np.einsum('ij,ij->i',a[:,0],np.cross(a[:,1],a[:,2])))/6
        if volume<=0:negative_volumes.append(part['name'])
    check(name+'/closed_component_orientation',not negative_volumes,'Intentional open graphic planes: '+', '.join(open_parts))
    return {'name':name,'triangles':len(t),'render_vertices':len(v),'source_components':len(p['source']),'material_slots':len(p['materials']),'dimensions_x_y_z_m':np.ptp(v,axis=0).tolist(),'intentional_open_components':open_parts}

def validate_glb(p):
    path=ROOT/'Exports/GLB'/('CSE_'+p['name']+'.glb');doc,access=glb_read(path);primitives=doc['meshes'][0]['primitives'];count=0
    for prim in primitives:
        attr=prim['attributes'];assert all(k in attr for k in ['POSITION','NORMAL','TANGENT','TEXCOORD_0','TEXCOORD_1']);v=access(attr['POSITION']);n=access(attr['NORMAL']);ta=access(attr['TANGENT']);inds=access(prim['indices']);assert len(inds)%3==0;assert inds.max()<len(v);assert prim['mode']==4;assert 0<=prim['material']<len(doc['materials']);count+=len(inds)//3
        assert all(np.isfinite(x).all() for x in [v,n,ta]);assert np.max(abs(np.linalg.norm(ta[:,:3],axis=1)-1))<1e-4;assert np.max(abs(np.sum(ta[:,:3]*n,axis=1)))<1e-4
        assert np.max(abs(v-np.asarray(p['vertices'])@R.T))<1e-6
    assert count==p['stats']['triangles'];check(p['name']+'/glb_binary_accessors_images',True,f'{len(doc["images"])} embedded PNGs; {count} triangles')
    scene=trimesh.load(str(path),force='scene',process=False);assert sum(len(g.faces) for g in scene.geometry.values())==count;assert np.allclose(np.ptp(scene.bounds,axis=0).ravel(),np.array(p['stats']['dimensions_xyz_m'])[[0,2,1]],atol=1e-6)
    check(p['name']+'/glb_independent_trimesh_load',True,'Trimesh '+trimesh.__version__)

def validate_fbx(p,path,label):
    try:
        nodes=decode_fbx(path)
        objects=top(nodes,'Objects')['children'];geo=next(o for o in objects if o['name']=='Geometry');v=child(geo,'Vertices')['props'][0].reshape(-1,3);indices=child(geo,'PolygonVertexIndex')['props'][0].copy();assert len(indices)==p['stats']['triangles']*3
        assert np.all(indices.reshape(-1,3)[:,-1]<0);indices[indices<0]=-indices[indices<0]-1;assert indices.min()>=0 and indices.max()<len(v)
        assert np.allclose(v,np.array(p['vertices'])@R.T,atol=1e-9);assert len(child(child(geo,'LayerElementNormal'),'Normals')['props'][0])==len(indices)*3
        uvs=[c for c in geo['children'] if c['name']=='LayerElementUV'];assert len(uvs)==2
        for uv in uvs:assert len(child(uv,'UV')['props'][0])==len(indices)*2
        assert len(child(child(geo,'LayerElementMaterial'),'Materials')['props'][0])==p['stats']['triangles']
        props=child(top(nodes,'GlobalSettings'),'Properties70')['children'];unit=next(x for x in props if x['props'][0]=='UnitScaleFactor')['props'][-1];assert unit==100.
        assert all('\x00\x01' in obj['props'][1] for obj in objects);ids=[obj['props'][0] for obj in objects];assert len(ids)==len(set(ids));ids=set(ids)|{0}
        for connection in top(nodes,'Connections')['children']:assert connection['props'][1] in ids and connection['props'][2] in ids
        texture_paths=[]
        for obj in objects:
            for element in walk(obj):
                if element['name']=='RelativeFilename':
                    rel=element['props'][0];assert not Path(rel).is_absolute();assert (path.parent/rel).resolve().is_file();texture_paths.append(rel)
        check(p['name']+'/'+label+'_structural_roundtrip',True,f'FBX 7400; correct arrays, topology, relative texture paths ({len(texture_paths)}), metre units.')
    except Exception:
        # The delivered Unity FBX files are Blender-native exports because
        # Unity rejects the tiny fallback writer's footer. When the
        # independent Blender re-import report is present, use its per-prop
        # topology/bounds/UV evidence for this standard FBX variant.
        report_path=ROOT/'Validation/blender_reimport_report.json'
        if not report_path.is_file(): raise
        report=json.loads(report_path.read_text())
        row=next((item for item in report.get('fbx',[]) if item.get('name')==p['name']),None)
        assert report.get('summary',{}).get('status')=='BLENDER AND FBX IMPORT PASS'
        assert row and row.get('status')=='PASS'
        check(p['name']+'/'+label+'_blender_reimport',True,'Blender-native FBX re-import passed; see Validation/blender_reimport_report.json')

def validate_textures():
    mats=json.loads((ROOT/'Source/materials.json').read_text());files=list((ASSET/'Textures').glob('*.png'));check('textures/count',len(files)==61,len(files))
    for name in mats:
        maps={}
        for kind in ['BaseColor','Normal','ORM','MetallicSmoothness']:
            im=Image.open(ASSET/'Textures'/f'CSE_{name}_{kind}.png');im.load();assert im.width==im.height and im.width in [512,1024];maps[kind]=np.array(im)
        orm=maps['ORM'];ms=maps['MetallicSmoothness'];assert np.all(orm[:,:,0]==255);assert np.max(abs(ms[:,:,0].astype(int)-orm[:,:,2]))==0;assert np.max(abs(ms[:,:,3].astype(int)-(255-orm[:,:,1].astype(int))))==0
        n=(maps['Normal'][:,:,:3].astype(float)/255)*2-1;assert np.max(abs(np.linalg.norm(n,axis=2)-1))<.02
        check('texture_set/'+name,True,'Original maps; ORM.R is constant white, not baked AO')

def validate_unity():
    metas=list(ASSET.rglob('*.meta'))
    if Path(str(ASSET)+'.meta').is_file():metas.append(Path(str(ASSET)+'.meta'))
    guids={};bad=[]
    for meta in metas:
        match=re.search(r'^guid: ([a-f0-9]{32})$',meta.read_text(),re.M);assert match,meta
        guid=match.group(1)
        if guid in guids:bad.append([str(guids[guid]),str(meta)])
        guids[guid]=meta
    check('unity/unique_meta_guids',not bad,str(len(guids))+' GUIDs')
    missing=[]
    for item in [ASSET,*ASSET.rglob('*')]:
        if item.name.endswith('.meta') or '__pycache__' in item.parts:continue
        if not Path(str(item)+'.meta').is_file():missing.append(str(item.relative_to(ASSET)))
    check('unity/meta_coverage',not missing,missing)
    whitelist={'0000000000000000f000000000000000','0000000000000000e000000000000000','933532a4fcc9baf4fa0491de14d08ed7'};missingrefs=[]
    for path in ASSET.rglob('*'):
        if path.suffix not in ['.prefab','.unity','.mat']:continue
        text=path.read_text();assert text.startswith('%YAML 1.1');assert '!u!' in text
        for guid in re.findall(r'guid: ([a-f0-9]{32})',text):
            if guid not in guids and guid not in whitelist:missingrefs.append([str(path),guid])
    check('unity/serialized_guid_references',not missingrefs,missingrefs or 'Package references resolved; external engine/URP shader references recognized.')
    yaml_count=0
    for path in ASSET.rglob('*'):
        if path.suffix not in ['.prefab','.unity','.mat','.meta']:continue
        text=re.sub(r'^%.*\n','',path.read_text(),flags=re.M)
        text=re.sub(r'^--- !u!\d+ &-?\d+.*$','---',text,flags=re.M)
        list(yaml.safe_load_all(text));yaml_count+=1
    check('unity/yaml_syntax',True,f'{yaml_count} files parsed with PyYAML; Unity field/API interpretation is covered by the external import report when present.')
    check('unity/12_prefabs',len(list((ASSET/'Prefabs').glob('*.prefab')))==12)
    check('unity/30_material_assets',len(list((ASSET/'Materials').rglob('*.mat')))==30)
    long=[str(p.relative_to(ROOT/'UnityProject')) for p in ASSET.rglob('*') if len(str(p.relative_to(ROOT/'UnityProject')))>=150]
    check('unity/asset_paths_under_150_characters',not long,long)
    for prefab in (ASSET/'Prefabs').glob('*.prefab'):
        text=prefab.read_text();assert 'm_LocalScale: {x: 1, y: 1, z: 1}' in text;assert 'MeshCollider:' in text and 'm_Convex: 0' in text
    check('unity/static_colliders_and_identity_roots',True,'Serialized inspection; collider/prefab validation is also recorded by the external Unity report when present.')
    package=ROOT/'ConstructionSiteEssentials_1.0.0.unitypackage'
    if package.is_file():
        with tarfile.open(package,'r:gz') as archive:
            entries=archive.getnames();paths=[n for n in entries if n.endswith('/pathname')];names=[archive.extractfile(n).read().decode() for n in paths]
            assert names and all(n.startswith('Assets/ConstructionSiteEssentials') for n in names)
            for n in paths:
                guid=n.split('/')[0];assert guid+'/asset.meta' in entries;meta=archive.extractfile(guid+'/asset.meta').read().decode();assert 'guid: '+guid in meta
        check('unitypackage/archive_structure',True,f'{len(paths)} assets/folders. Unity package structure verified; Editor import evidence is in Documentation/UnityImportReport.txt when present.')

def main():
    for p in DATA:
        for fn in [validate_geometry,validate_glb]:
            try:
                result=fn(p)
                if fn is validate_geometry:REPORT['props'].append(result)
            except Exception as exc:check(p['name']+'/'+fn.__name__,False,type(exc).__name__+': '+str(exc))
        for path,label in [(ROOT/'Exports/FBX'/f'CSE_{p["name"]}.fbx','fbx_export'),(ASSET/'Models'/f'CSE_{p["name"]}.fbx','fbx_unity')]:
            try:validate_fbx(p,path,label)
            except Exception as exc:check(p['name']+'/'+label,False,type(exc).__name__+': '+str(exc))
    for fn in [validate_textures,validate_unity]:
        try:fn()
        except Exception as exc:check(fn.__name__,False,type(exc).__name__+': '+str(exc))
    # Promote completed external checks into the report when their evidence is
    # present in this delivery. Remaining items stay explicit: URP, manual
    # visual/performance review, Khronos validation and publisher approval.
    pending=list(REPORT['pending'])
    blend_report=ROOT/'Validation/blender_reimport_report.json'
    if blend_report.is_file():
        try:
            if json.loads(blend_report.read_text()).get('summary',{}).get('status')=='BLENDER AND FBX IMPORT PASS':
                pending=[item for item in pending if not item.startswith('Execute build_blender.py') and not item.startswith('Import FBX files')]
        except Exception:
            pass
    unity_report=ASSET/'Documentation/UnityImportReport.txt'
    if unity_report.is_file() and 'Errors: 0' in unity_report.read_text():
        pending=[item for item in pending if not item.startswith('Compile the supplied Editor C#')]
        pending=[('Test URP separately in a real Unity project; Built-In import, materials, axes, scale and colliders are covered by the attached Unity report.') if item.startswith('Test URP and Built-In separately') else item for item in pending]
        pending=[('Manually inspect the rebuilt demo, lightmap baking and target-device performance; automated Built-In demo rebuild completed.') if item.startswith('Open/rebuild the Unity demo') else item for item in pending]
    REPORT['pending']=pending
    fails=[c for c in REPORT['checks'] if c['status']=='FAIL'];
    evidence_complete=(blend_report.is_file() and unity_report.is_file() and 'Errors: 0' in unity_report.read_text())
    status='LOCAL + TARGETED EXTERNAL CHECKS PASS — URP/STORE REVIEW PENDING' if not fails and evidence_complete else 'LOCAL CHECKS PASS — EXTERNAL EDITOR TESTS PENDING' if not fails else 'LOCAL CHECKS FAILED'
    REPORT['summary']={'passed':len(REPORT['checks'])-len(fails),'failed':len(fails),'pending_external_categories':len(REPORT['pending']),'all_prop_triangles':sum(p['stats']['triangles'] for p in DATA),'status':status}
    (ROOT/'Validation/validation_report.json').write_text(json.dumps(REPORT,indent=2))
    text='# Construction Site Essentials — validation report\n\n'+REPORT['summary']['status']+'\n\n'
    text+=f"{REPORT['summary']['passed']} local checks passed; {len(fails)} failed. These results are NOT Blender, Unity Editor, Khronos Validator or Asset Store approval.\n\n## Pending external checks\n\n"+'\n'.join('- [ ] '+x for x in REPORT['pending'])+'\n\n## Local results\n\n| Check | Result | Detail |\n|---|---|---|\n'
    for c in REPORT['checks']:text+='| '+c['check']+' | '+c['status']+' | '+c['detail'].replace('|','/').replace('\n',' ')+' |\n'
    (ROOT/'Validation/VALIDATION_REPORT.md').write_text(text)
    print(json.dumps(REPORT['summary'],indent=2));return bool(fails)
if __name__=='__main__':sys.exit(main())
