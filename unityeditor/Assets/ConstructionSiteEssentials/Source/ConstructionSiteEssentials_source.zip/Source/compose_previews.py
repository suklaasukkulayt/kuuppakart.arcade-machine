"""Package presentation using actual generated mesh renders; no synthetic concept imagery."""
from pathlib import Path
import json, math, html
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
ROOT=Path(__file__).resolve().parent.parent;P=ROOT/'Previews';DATA=json.loads((ROOT/'Source/mesh_data.json').read_text());SPECS=json.loads((ROOT/'Source/materials.json').read_text())
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(size,bold=False):return ImageFont.truetype(BOLD if bold else FONT,size)
INK='#18242B';GRAY='#647077';PAPER='#F2F3EF';ORANGE='#DF641D';LINE='#D9DED8'
def text(draw,xy,string,size=24,fill=INK,bold=False):draw.text(xy,string,font=font(size,bold),fill=fill)
def fit(source,box):return ImageOps.contain(source,box,Image.Resampling.LANCZOS)
def save(im,name):im.save(P/name,compress_level=3)

im=Image.new('RGB',(2200,1710),PAPER);d=ImageDraw.Draw(im);d.rectangle((70,62,92,202),fill=ORANGE)
text(d,(126,50),'CONSTRUCTION',72,bold=True);text(d,(126,133),'SITE ESSENTIALS',72,bold=True)
text(d,(1440,82),'12 ORIGINAL 3D PROPS',33,bold=True);text(d,(1440,135),'FBX  /  GLB  /  PBR MAPS',26,GRAY)
hero=Image.open(P/'Hero_ActualMesh.png').convert('RGB');im.paste(hero,(0,239))
d=ImageDraw.Draw(im);d.rectangle((0,1630,2200,1710),fill=INK)
text(d,(70,1653),'ACTUAL MESH RENDER',25,'#FFFFFF',True);text(d,(860,1653),'Metre scale  /  Ground pivots  /  Two UV channels',25,'#E1E5E2')
save(im,'01_Hero_Preview.png')

W,H=2480,2160;im=Image.new('RGB',(W,H),PAPER);d=ImageDraw.Draw(im)
text(d,(62,47),'THE COMPLETE SET',62,bold=True);text(d,(64,128),'12 unique props. Shared materials. The images below render the delivered geometry.',26,GRAY)
cardw,cardh=571,601;xpad=61;ypad=207;gap=24
for i,p in enumerate(DATA):
    x=xpad+(i%4)*(cardw+gap);y=ypad+(i//4)*(cardh+gap)
    d.rounded_rectangle((x,y,x+cardw,y+cardh),radius=16,fill='#FFFFFF',outline=LINE,width=2)
    source=fit(Image.open(P/'Individual'/f'{p["name"]}.png').convert('RGB'),(cardw-24,480));im.paste(source,(x+(cardw-source.width)//2,y+16))
    d=ImageDraw.Draw(im);d.rectangle((x+22,y+512,x+26,y+579),fill=ORANGE)
    text(d,(x+42,y+511),p['display'].upper(),25,bold=True)
    s=p['stats'];text(d,(x+42,y+551),f'{s["triangles"]:,} triangles  |  {s["material_slots"]} material slot'+('s' if s['material_slots']!=1 else ''),20,GRAY)
    d.rounded_rectangle((x+18,y+18,x+80,y+60),radius=9,fill=INK);text(d,(x+31,y+24),f'{i+1:02d}',22,'#FFFFFF',True)
text(d,(64,2109),'Individual props normalized to frame, not shown at the same scale. Static meshes; no LOD variants or animation.',23,GRAY)
save(im,'02_All_12_Props.png')

# True chart projection from shipped UV arrays, not decorative wire art.
def uv_plot(p,channel,size=1000):
    im=Image.new('RGB',(size,size),'#FDFEF9');d=ImageDraw.Draw(im);margin=30;extent=size-2*margin
    for k in range(11):
        q=margin+k*extent/10;d.line((q,margin,q,size-margin),fill='#E7EAE5',width=1);d.line((margin,q,size-margin,q),fill='#E7EAE5',width=1)
    uv=np.asarray(p[channel]);colors=['#294957','#37758A','#C5672C','#6C897C','#997349']
    for k,face in enumerate(p['faces']):
        points=[(margin+float(uv[v,0])*extent,margin+(1-float(uv[v,1]))*extent) for v in face]
        if channel=='uv1':d.polygon(points,fill=colors[k%len(colors)],outline='#FFFFFF',width=1)
        else:d.line(points+[points[0]],fill=colors[k%len(colors)],width=1)
    d.rectangle((margin,margin,size-margin,size-margin),outline=INK,width=3);return im
for p in DATA:uv_plot(p,'uv1',1000).save(P/'Technical'/f'UV1_{p["name"]}.png',compress_level=3)

im=Image.new('RGB',(2400,1550),PAPER);d=ImageDraw.Draw(im)
text(d,(60,48),'GEOMETRY + UV INSPECTION',56,bold=True);text(d,(62,126),'Wheelbarrow  /  4,688 triangles  /  34 editable source components  /  Two UV channels',26,GRAY)
x0,y0,w,h=60,220,1390,960;d.rectangle((x0,y0,x0+w,y0+h),fill='#FFFFFF',outline=LINE,width=2)
wire=fit(Image.open(P/'Technical/Wire_Wheelbarrow.png'),(w-30,h-60));im.paste(wire,(x0+(w-wire.width)//2,y0+(h-wire.height)//2))
uv=uv_plot(DATA[3],'uv1',870);im.paste(uv,(1480,220));d=ImageDraw.Draw(im)
text(d,(83,1203),'TRIANGULATED RUNTIME MESH',29,bold=True);text(d,(83,1250),'Original component meshes are retained in the source data.',25,GRAY)
text(d,(1490,1130),'UV1 — UNIQUE LIGHTMAP CHARTS',26,bold=True)
text(d,(1490,1175),'Charts are packed inside 0–1.',24,GRAY);text(d,(1490,1213),'0.0018 UV margin per chart side.',24,GRAY)
d.line((60,1335,2340,1335),fill=LINE,width=2)
text(d,(62,1370),'UV0',30,ORANGE,True);text(d,(174,1370),'Reusable tiling/graphic coordinates; intentional overlap and repetition.',26)
text(d,(62,1422),'UV1',30,ORANGE,True);text(d,(174,1422),'Local checks find no overlapping charts. Unity bake verification remains pending.',26)
save(im,'03_Wireframe_and_UV.png')

im=Image.new('RGB',(2200,1390),PAPER);d=ImageDraw.Draw(im);text(d,(60,43),'REUSABLE PBR MATERIALS',55,bold=True)
text(d,(63,118),'15 original texture sets  /  61 PNG maps  /  512 px and 1024 px  /  Opaque metal–rough workflow',25,GRAY)
texroot=ROOT/'UnityProject/Assets/ConstructionSiteEssentials/Textures'
for i,(name,spec) in enumerate(SPECS.items()):
    col=i%5;row=i//5;x=60+col*427;y=202+row*356
    d.rounded_rectangle((x,y,x+403,y+332),radius=12,fill='white',outline=LINE,width=2)
    base=Image.open(texroot/f'CSE_{name}_BaseColor.png').convert('RGB').resize((249,239),Image.Resampling.LANCZOS)
    normal=Image.open(texroot/f'CSE_{name}_Normal.png').convert('RGB').resize((113,113),Image.Resampling.LANCZOS)
    packed=Image.open(texroot/f'CSE_{name}_ORM.png').convert('RGB').resize((113,113),Image.Resampling.LANCZOS)
    im.paste(base,(x+14,y+14));im.paste(normal,(x+276,y+14));im.paste(packed,(x+276,y+140));d=ImageDraw.Draw(im)
    label=''.join((' '+ch if ch.isupper() and j else ch) for j,ch in enumerate(name))
    text(d,(x+17,y+270),label,23,bold=True);text(d,(x+17,y+302),'Base color  /  Normal  /  ORM preview',15,GRAY)
text(d,(63,1306),'Unity materials use separate metallic + smoothness packing. ORM red is constant white, not baked ambient occlusion.',23,GRAY)
save(im,'04_PBR_Materials.png')

cards=''.join(f'<figure><img loading="lazy" src="Individual/{p["name"]}.png" alt="Actual mesh render of {html.escape(p["display"])}"><figcaption><strong>{html.escape(p["display"])}</strong><span>{p["stats"]["triangles"]:,} triangles · {p["stats"]["material_slots"]} materials</span></figcaption></figure>' for p in DATA)
page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Construction Site Essentials — preview gallery</title><style>body{margin:0;background:#f2f3ef;color:#18242b;font:16px/1.6 system-ui,sans-serif}main{max-width:1400px;margin:auto;padding:36px 20px}h1{font-size:clamp(34px,5vw,64px);line-height:1.05}small{color:#647077}img{max-width:100%;height:auto;display:block}.note{background:#fff2e7;border-left:5px solid #df641d;padding:18px 24px;margin:24px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}figure{margin:0;border:1px solid #d9ded8;border-radius:12px;overflow:hidden;background:white}figcaption{padding:15px}strong,span{display:block}span{color:#647077;font-size:14px}a{color:#8d3c15}footer{padding:32px 0}</style><main><small>CONSTRUCTION SITE ESSENTIALS / 1.0.0</small><h1>12 original construction props.</h1><p>Actual mesh renders. FBX + GLB. Original procedural textures and editable source data.</p><div class="note"><strong>Submission candidate — external editor checks remain.</strong>The binaries and package structure exist. Blender was unavailable: run the supplied generator to create the .blend source. Unity Editor import/compilation and Asset Store approval have not been performed.</div><img src="01_Hero_Preview.png" alt="All twelve construction props rendered together"><h2>Inspect the complete set</h2><div class="grid">'''+cards+'''</div><h2>Topology and UVs</h2><img loading="lazy" src="03_Wireframe_and_UV.png" alt="Wheelbarrow wireframe and actual unique UV charts"><h2>Materials</h2><img loading="lazy" src="04_PBR_Materials.png" alt="Fifteen original material map sets"><footer><a href="../README.md">README</a> · <a href="../Validation/VALIDATION_REPORT.md">Validation report</a> · <a href="../Documentation/PROVENANCE_AND_OWNERSHIP.md">Provenance and ownership</a></footer></main></html>'''
(P/'index.html').write_text(page)
print('COMPOSITED: hero, 12-prop catalogue, wireframe/UV board, materials board, 12 UV charts, offline gallery.')
