"""Original GLB 2.0 and FBX 7.4 binary writers for Construction Site Essentials.
No external SDK/runtime is bundled. Source geometry remains in mesh_data.json.
"""
from __future__ import annotations
import json,struct,zlib,hashlib,math,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent.parent;SRC=ROOT/'Source';TEX=ROOT/'UnityProject/Assets/ConstructionSiteEssentials/Textures'
MATS=json.loads((SRC/'materials.json').read_text())

# Proper rotation from Z-up authoring to Y-up, +Z-front interchange axes.
R=np.array([[1,0,0],[0,0,1],[0,-1,0]],float)
def tangents(v,n,uv,tri):
    out=np.zeros_like(v);bt=np.zeros_like(v)
    for t in tri:
        e1=v[t[1]]-v[t[0]];e2=v[t[2]]-v[t[0]];d1=uv[t[1]]-uv[t[0]];d2=uv[t[2]]-uv[t[0]];d=d1[0]*d2[1]-d1[1]*d2[0]
        if abs(d)<1e-12:continue
        a=(e1*d2[1]-e2*d1[1])/d;b=(e2*d1[0]-e1*d2[0])/d
        out[t]+=a;bt[t]+=b
    out-=n*np.sum(n*out,axis=1)[:,None];length=np.linalg.norm(out,axis=1)
    bad=length<1e-12
    if np.any(bad):
        nn=n[bad];ref=np.tile([1.,0,0],(len(nn),1));ref[np.abs(nn[:,0])>.9]=[0,1,0];out[bad]=np.cross(nn,ref)
    out/=np.maximum(np.linalg.norm(out,axis=1,keepdims=True),1e-12);w=np.where(np.sum(np.cross(n,out)*bt,axis=1)<0,-1.,1.)
    return np.column_stack([out,w])

def glb(p):
    v=np.array(p['vertices'])@R.T;n=np.array(p['normals'])@R.T;uv=np.array(p['uv0']);uv[:,1]=1-uv[:,1];uv1=np.array(p['uv1']);uv1[:,1]=1-uv1[:,1];tri=np.array(p['triangles']);tm=np.array(p['tri_material'])
    blob=bytearray();views=[];access=[];images=[];textures=[];materials=[]
    def view(data,target=None):
        while len(blob)%4:blob.append(0)
        ix=len(views);obj={'buffer':0,'byteOffset':len(blob),'byteLength':len(data)}
        if target:obj['target']=target
        views.append(obj);blob.extend(data);return ix
    def acc(a,component,kind,target):
        a=np.array(a,dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[component]);i=len(access)
        obj={'bufferView':view(a.tobytes(),target),'componentType':component,'count':len(a),'type':kind}
        if kind=='VEC3' and i==0:obj.update(min=a.min(0).tolist(),max=a.max(0).tolist())
        access.append(obj);return i
    va=acc(v,5126,'VEC3',34962);na=acc(n,5126,'VEC3',34962);ua=acc(uv,5126,'VEC2',34962);u1=acc(uv1,5126,'VEC2',34962);ta=acc(tangents(v,n,uv,tri),5126,'VEC4',34962)
    def tex(name,suffix):
        file=TEX/f'CSE_{name}_{suffix}.png';image=len(images);images.append({'name':file.stem,'bufferView':view(file.read_bytes()),'mimeType':'image/png'});textures.append({'sampler':0,'source':image});return len(textures)-1
    for name in p['materials']:
        mat={'name':'CSE_'+name,'pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'baseColorTexture':{'index':tex(name,'BaseColor')},'metallicFactor':1,'roughnessFactor':1,'metallicRoughnessTexture':{'index':tex(name,'ORM')}},'normalTexture':{'index':tex(name,'Normal'),'scale':.5},'doubleSided':False}
        if name=='WorklightLens':mat.update(emissiveFactor=[1,1,1],emissiveTexture={'index':tex(name,'Emission')})
        materials.append(mat)
    prim=[]
    for i,mat in enumerate(materials):prim.append({'attributes':{'POSITION':va,'NORMAL':na,'TANGENT':ta,'TEXCOORD_0':ua,'TEXCOORD_1':u1},'indices':acc(tri[tm==i].flatten(),5125,'SCALAR',34963),'material':i,'mode':4})
    doc={'asset':{'version':'2.0','generator':'Construction Site Essentials original procedural authoring 1.0.0'},'scene':0,'scenes':[{'name':p['display'],'nodes':[0]}],'nodes':[{'name':p['name'],'mesh':0}],'meshes':[{'name':p['name'],'primitives':prim}],'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access,'materials':materials,'images':images,'textures':textures,'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}],'extras':{'units':'metres','front':'+Z','up':'+Y','pivot':'bottom centre','source':'Source/mesh_data.json','aiAssisted':True}}
    js=json.dumps(doc,separators=(',',':')).encode();js+=b' '*((-len(js))%4);blob+=b'\x00'*((-len(blob))%4)
    result=b'glTF'+struct.pack('<II',2,12+8+len(js)+8+len(blob))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(blob),b'BIN\x00')+blob
    (ROOT/'Exports/GLB'/f'CSE_{p["name"]}.glb').write_bytes(result)

class N:
    def __init__(self,name,*props,children=()):self.name=name;self.props=props;self.children=list(children)
def S(v):return ('S',str(v))
def I(v):return ('I',int(v))
def L(v):return ('L',int(v))
def D(v):return ('D',float(v))
def A(t,v):return (t,np.array(v))
def B(v):return ('C',bool(v))
def P(name,kind,*values,flag='',label=None):
    """Create an FBX Properties70 property with Blender-compatible labels.

    FBX stores a semantic label alongside the property type.  Blender's
    importer validates these labels for typed properties such as ``double``,
    ``int`` and ``ColorRGB``; leaving them empty produces an FBX that can be
    written but cannot be re-imported.  Standard Number/Color/vector
    properties intentionally keep the empty label used by the FBX format.
    """
    if label is None:
        label={'double':'Number','int':'Integer','ColorRGB':'Color'}.get(kind,'')
    vals=[D(x) if isinstance(x,(float,np.floating)) else I(x) if isinstance(x,(int,np.integer)) else S(x) for x in values]
    return N('P',S(name),S(kind),S(label),S(flag),*vals)
def encode_prop(prop):
    t,v=prop
    if t in 'YILFDC':return t.encode()+struct.pack({'Y':'<h','I':'<i','L':'<q','F':'<f','D':'<d','C':'<?'}[t],v)
    if t in ['S','R']:
        b=v.encode() if t=='S' else v;return t.encode()+struct.pack('<I',len(b))+b
    typ={'d':'<f8','f':'<f4','i':'<i4','l':'<i8','b':'u1'}[t];a=np.array(v,dtype=typ).ravel();b=a.tobytes();c=zlib.compress(b,6)
    return t.encode()+struct.pack('<III',a.size,1,len(c))+c

def encode_node(node,offset):
    name=node.name.encode();props=b''.join(encode_prop(p) for p in node.props);headsize=13+len(name)+len(props);children=b''
    for ch in node.children:children+=encode_node(ch,offset+headsize+len(children))
    if node.children:children+=b'\0'*13
    end=offset+headsize+len(children)
    return struct.pack('<IIIB',end,len(node.props),len(props),len(name))+name+props+children

def fbx(p, destination=None, texture_prefix="../../UnityProject/Assets/ConstructionSiteEssentials/Textures/"):
    v=np.array(p['vertices'])@R.T;n=np.array(p['normals'])@R.T;tri=np.array(p['triangles']);corners=tri.ravel();uv=np.array(p['uv0']);uv1=np.array(p['uv1']);mats=p['materials']
    geo_id=1001;model_id=1002;poly=tri.copy();poly[:,-1]=-poly[:,-1]-1
    geo=N('Geometry',L(geo_id),S(p['name']+'\x00\x01Geometry'),S('Mesh'),children=[N('GeometryVersion',I(124)),N('Vertices',A('d',v)),N('PolygonVertexIndex',A('i',poly)),N('LayerElementNormal',I(0),children=[N('Version',I(101)),N('Name',S('Normals')),N('MappingInformationType',S('ByPolygonVertex')),N('ReferenceInformationType',S('Direct')),N('Normals',A('d',n[corners]))]),N('LayerElementMaterial',I(0),children=[N('Version',I(101)),N('Name',S('Materials')),N('MappingInformationType',S('ByPolygon')),N('ReferenceInformationType',S('IndexToDirect')),N('Materials',A('i',p['tri_material']))])])
    for layer,data in enumerate([uv,uv1]):
        geo.children.append(N('LayerElementUV',I(layer),children=[N('Version',I(101)),N('Name',S('UVMap' if layer==0 else 'LightmapUV')),N('MappingInformationType',S('ByPolygonVertex')),N('ReferenceInformationType',S('Direct')),N('UV',A('d',data[corners]))]))
    geo.children.extend([N('Layer',I(0),children=[N('Version',I(100)),*[N('LayerElement',children=[N('Type',S(t)),N('TypedIndex',I(0))]) for t in ['LayerElementNormal','LayerElementMaterial','LayerElementUV']]]),N('Layer',I(1),children=[N('Version',I(100)),N('LayerElement',children=[N('Type',S('LayerElementUV')),N('TypedIndex',I(1))])])])
    model=N('Model',L(model_id),S(p['name']+'\x00\x01Model'),S('Mesh'),children=[N('Version',I(232)),N('Properties70',children=[P('Lcl Translation','Lcl Translation',0.,0.,0.,flag='A'),P('Lcl Rotation','Lcl Rotation',0.,0.,0.,flag='A'),P('Lcl Scaling','Lcl Scaling',1.,1.,1.,flag='A'),P('RotationActive','bool',1),P('InheritType','enum',1)]),N('Shading',B(True)),N('Culling',S('CullingOff'))])
    objects=[geo,model];cons=[N('C',S('OO'),L(geo_id),L(model_id)),N('C',S('OO'),L(model_id),L(0))]
    for i,name in enumerate(mats):
        mid=2000+i;tid=3000+i;vid=4000+i;spec=MATS[name];c=[1.,1.,1.]
        objects.append(N('Material',L(mid),S('CSE_'+name+'\x00\x01Material'),S(''),children=[N('Version',I(102)),N('ShadingModel',S('phong')),N('MultiLayer',I(0)),N('Properties70',children=[P('DiffuseColor','Color',*map(float,c),flag='A'),P('DiffuseFactor','Number',1.,flag='A'),P('SpecularColor','Color',.22,.22,.22,flag='A'),P('Shininess','Number',max(2.,(1-spec['roughness'])*80),flag='A'),P('Opacity','Number',1.,flag='A'),P('Metallic','Number',float(spec['metallic']),flag='A'),P('Roughness','Number',float(spec['roughness']),flag='A')])]))
        # Deliberate relative path; no absolute machine path leaks.
        rel=texture_prefix+'CSE_'+name+'_BaseColor.png'
        objects.append(N('Texture',L(tid),S('CSE_'+name+'\x00\x01Texture'),S(''),children=[N('Type',S('TextureVideoClip')),N('Version',I(202)),N('TextureName',S('CSE_'+name+'\x00\x01Texture')),N('Media',S('CSE_'+name+'\x00\x01Video')),N('FileName',S(rel)),N('RelativeFilename',S(rel)),N('ModelUVTranslation',D(0.),D(0.)),N('ModelUVScaling',D(1.),D(1.)),N('Texture_Alpha_Source',S('None')),N('Cropping',I(0),I(0),I(0),I(0))]))
        objects.append(N('Video',L(vid),S('CSE_'+name+'\x00\x01Video'),S('Clip'),children=[N('Type',S('Clip')),N('Properties70',children=[P('Path','KString',rel)]),N('UseMipMap',I(0)),N('Filename',S(rel)),N('RelativeFilename',S(rel))]))
        cons.extend([N('C',S('OO'),L(mid),L(model_id)),N('C',S('OO'),L(vid),L(tid)),N('C',S('OP'),L(tid),L(mid),S('DiffuseColor'))])
    globals=N('GlobalSettings',children=[N('Version',I(1000)),N('Properties70',children=[P('UpAxis','int',1),P('UpAxisSign','int',1),P('FrontAxis','int',2),P('FrontAxisSign','int',1),P('CoordAxis','int',0),P('CoordAxisSign','int',1),P('OriginalUpAxis','int',2),P('OriginalUpAxisSign','int',1),P('UnitScaleFactor','double',100.),P('OriginalUnitScaleFactor','double',100.),P('AmbientColor','ColorRGB',0.,0.,0.),P('DefaultCamera','KString','Producer Perspective'),P('TimeMode','enum',0)])])
    stamp=N('CreationTimeStamp',children=[N('Version',I(1000)),N('Year',I(2026)),N('Month',I(9)),N('Day',I(15)),N('Hour',I(0)),N('Minute',I(0)),N('Second',I(0)),N('Millisecond',I(0))])
    header=N('FBXHeaderExtension',children=[N('FBXHeaderVersion',I(1003)),N('FBXVersion',I(7400)),N('EncryptionType',I(0)),stamp,N('Creator',S('CSE Original Procedural Authoring 1.0.0'))])
    document=N('Document',L(1),S('Scene'),S('Scene'),children=[N('Properties70',children=[P('SourceObject','object'),P('ActiveAnimStackName','KString','')]),N('RootNode',L(0))])
    definitions=N('Definitions',children=[N('Version',I(100)),N('Count',I(len(objects)))])
    for kind,count in [('Geometry',1),('Model',1),('Material',len(mats)),('Texture',len(mats)),('Video',len(mats))]:
        definitions.children.append(N('ObjectType',S(kind),children=[N('Count',I(count))]))
    nodes=[header,N('FileId',('R',hashlib.md5(p['name'].encode()).digest())),N('CreationTime',S('2026-09-15 00:00:00:000')),N('Creator',S('CSE Original Procedural Authoring 1.0.0')),globals,N('Documents',children=[N('Count',I(1)),document]),N('References'),definitions,N('Objects',children=objects),N('Connections',children=cons),N('Takes',children=[N('Current',S(''))])]
    out=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
    for node in nodes:out+=encode_node(node,len(out))
    out+=b'\0'*13+bytes.fromhex('fabcab09d0c8d466b176fb831cf7267e');out+=b'\0'*((-len(out))%16);out+=struct.pack('<I',0)+struct.pack('<I',7400)+b'\0'*120+bytes.fromhex('f85a8c6adef5d97eece90ce3758f290b')
    (destination or ROOT/'Exports/FBX'/f'CSE_{p["name"]}.fbx').write_bytes(out)

def main():
    data=json.loads((SRC/'mesh_data.json').read_text())
    for p in data:glb(p);fbx(p);print('EXPORTED',p['name'],flush=True)
if __name__=='__main__':main()
