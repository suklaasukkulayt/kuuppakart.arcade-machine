"""Actual-mesh studio previews. Uses VTK's offscreen PBR renderer, not image synthesis."""
from __future__ import annotations
import os
os.environ['VTK_DEFAULT_OPENGL_WINDOW']='vtkEGLRenderWindow'
import json,sys,math
from pathlib import Path
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent;SRC=ROOT/'Source';TEX=ROOT/'UnityProject/Assets/ConstructionSiteEssentials/Textures';PRE=ROOT/'Previews'
DATA=json.loads((SRC/'mesh_data.json').read_text());MATS=json.loads((SRC/'materials.json').read_text());CACHE={}

def load_texture(name):
    if name not in CACHE:
        reader=vtk.vtkPNGReader();reader.SetFileName(str(TEX/name));reader.Update();texture=vtk.vtkTexture();texture.SetInputConnection(reader.GetOutputPort());texture.InterpolateOn();texture.RepeatOn();texture.UseSRGBColorSpaceOn();CACHE[name]=(reader,texture)
    return CACHE[name][1]

def envtex():
    H,W=256,512;y,x=np.mgrid[:H,:W];u=x/W;v=y/H
    base=np.zeros((H,W,3),np.float32);base[:]=[.55,.60,.63]
    base*= (.55+.55*v)[:,:,None]
    # Original analytical studio light panels on a neutral panorama.
    for cx,cy,sx,sy,power,col in [(.21,.72,.10,.15,4.,[1,.97,.93]),(.75,.64,.12,.23,2.2,[.94,.97,1.]),(.47,.86,.16,.10,3.2,[1,1,1])]:
        du=np.minimum(abs(u-cx),1-abs(u-cx));g=np.exp(-((du/sx)**6+((v-cy)/sy)**6));base+=g[:,:,None]*np.array(col)[None,None,:]*power
    img=vtk.vtkImageData();img.SetDimensions(W,H,1);ar=numpy_to_vtk(base.reshape(-1,3),deep=True);ar.SetNumberOfComponents(3);img.GetPointData().SetScalars(ar)
    tex=vtk.vtkTexture();tex.SetInputData(img);tex.InterpolateOn();tex.MipmapOn();return tex
ENV=envtex()

def polydata(p,matidx=None):
    v=np.asarray(p['vertices'],dtype=np.float32);n=np.asarray(p['normals'],dtype=np.float32);uv=np.asarray(p['uv0'],dtype=np.float32);tri=np.asarray(p['triangles'],dtype=np.int64)
    if matidx is not None:tri=tri[np.array(p['tri_material'])==matidx]
    mesh=vtk.vtkPolyData();points=vtk.vtkPoints();points.SetData(numpy_to_vtk(v,deep=True));mesh.SetPoints(points)
    cells=vtk.vtkCellArray();cells.SetData(numpy_to_vtkIdTypeArray(np.arange(0,(len(tri)+1)*3,3,dtype=np.int64),deep=True),numpy_to_vtkIdTypeArray(tri.reshape(-1),deep=True));mesh.SetPolys(cells)
    norm=numpy_to_vtk(n,deep=True);norm.SetName('Normals');mesh.GetPointData().SetNormals(norm)
    coords=numpy_to_vtk(uv,deep=True);coords.SetName('UVMap');mesh.GetPointData().SetTCoords(coords)
    return mesh

def actors(p,pos=(0,0,0),angle=0,scale=1,wire=False):
    result=[]
    for mi,mat in enumerate(p['materials']):
        mesh=polydata(p,mi);mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(mesh);mapper.ScalarVisibilityOff();act=vtk.vtkActor();act.SetMapper(mapper);act.SetPosition(*pos);act.SetScale(scale);act.RotateZ(angle);pr=act.GetProperty()
        if wire:
            pr.SetColor(.08,.20,.22);pr.SetRepresentationToWireframe();pr.SetLineWidth(.7);pr.LightingOff()
        else:
            pr.SetInterpolationToPBR();pr.BackfaceCullingOn();pr.SetColor(1,1,1);pr.SetMetallic(MATS[mat]['metallic']);pr.SetRoughness(MATS[mat]['roughness']);pr.SetBaseColorTexture(load_texture('CSE_'+mat+'_BaseColor.png'))
            # Material PBR response is real; normal maps are included in the pack but
            # kept off in marketing previews to make topology/shape easy to inspect.
            if mat=='WorklightLens':pr.SetEmissiveFactor(.45,.38,.19)
        result.append(act)
    return result

def setup(size):
    ren=vtk.vtkRenderer();ren.SetBackground(.925,.93,.916);ren.SetEnvironmentTexture(ENV);ren.UseImageBasedLightingOff();ren.AutomaticLightCreationOff()
    for pos,power,col in [((-3,-4,6),2.5,(1,.98,.95)),((4,-1,3),1.6,(.94,.97,1)),((0,5,5),3.0,(1,1,1))]:
        l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(*pos);l.SetFocalPoint(0,0,.3);l.SetIntensity(power);l.SetColor(*col);l.SetPositional(False);ren.AddLight(l)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(0);win.AddRenderer(ren);ren.UseFXAAOn()
    basic=vtk.vtkRenderStepsPass();ssao=vtk.vtkSSAOPass();ssao.SetDelegatePass(basic);ssao.SetRadius(.12);ssao.SetBias(.002);ssao.SetKernelSize(32);ssao.BlurOn()
    tone=vtk.vtkToneMappingPass();tone.SetDelegatePass(ssao);tone.SetToneMappingType(vtk.vtkToneMappingPass.GenericFilmic);tone.SetExposure(1.0);ren.SetPass(tone)
    return ren,win

def floor(ren,extent=20):
    plane=vtk.vtkPlaneSource();plane.SetOrigin(-extent,-extent,-.002);plane.SetPoint1(extent,-extent,-.002);plane.SetPoint2(-extent,extent,-.002);plane.Update();mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(plane.GetOutputPort());act=vtk.vtkActor();act.SetMapper(mapper);pr=act.GetProperty();pr.SetInterpolationToPBR();pr.SetColor(.72,.74,.70);pr.SetRoughness(.95);ren.AddActor(act)

def capture(win,path):
    win.Render();wti=vtk.vtkWindowToImageFilter();wti.SetInput(win);wti.SetInputBufferTypeToRGB();wti.ReadFrontBufferOff();wti.Update();writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(wti.GetOutputPort());writer.Write();win.Finalize()

def single(p,wire=False,size=(820,740)):
    ren,win=setup(size)
    if not wire:floor(ren)
    for a in actors(p,wire=wire):ren.AddActor(a)
    vv=np.array(p['vertices']);center=(vv.min(0)+vv.max(0))/2;dim=np.ptp(vv,axis=0);d=max(dim)
    camera=ren.GetActiveCamera();camera.SetPosition(*(center+np.array([1.5,-2.7,1.7])*d));camera.SetFocalPoint(*center);camera.SetViewUp(0,0,1);camera.ParallelProjectionOn()
    ren.ResetCamera();camera.SetParallelScale(camera.GetParallelScale()*.94)
    # ResetCamera includes ground; restore analytically fitted size after floor.
    direction=np.array([1.5,-2.7,1.7]);direction/=np.linalg.norm(direction);right=np.cross(direction,[0,0,1]);right/=np.linalg.norm(right);up=np.cross(right,direction)
    dy=(vv-center)@up;dx=(vv-center)@right;fit=max(np.ptp(dy)/2,np.ptp(dx)/2*size[1]/size[0])*1.24
    camera.SetParallelScale(fit);camera.SetFocalPoint(*center);camera.SetPosition(*(center+direction*d*5));ren.ResetCameraClippingRange()
    name='Wire_'+p['name'] if wire else p['name'];out=PRE/('Technical' if wire else 'Individual')/(name+'.png');capture(win,out);print('RENDERED',name,flush=True)

def hero():
    ren,win=setup((2200,1450));floor(ren)
    layout={
    'SafetyBarrier':((-.25,.78,0),0), 'RoadSign':((-1.55,.55,0),-12),'PortableWorkLight':((1.43,.70,0),-13),
    'Wheelbarrow':((.35,-.10,0),-23),'Shovel':((-1.05,.2,0),-8),'TrafficCone':((-1.33,-.53,0),0),
    'CautionSign':((1.40,-.62,0),-13),'Toolbox':((.65,-.93,0),-8),'HardHat':((-.02,-.92,0),-12),
    'CementBag':((-.71,-.97,0),10),'BrickStack':((-1.80,-.90,0),-15),'RebarBundle':((-.12,-1.52,0),-5)}
    for p in DATA:
        pos,a=layout[p['name']]
        for actor in actors(p,pos,a):ren.AddActor(actor)
    cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetPosition(4.9,-8.5,5.5);cam.SetFocalPoint(0,-.13,.65);cam.SetViewUp(0,0,1);cam.SetParallelScale(2.19);ren.ResetCameraClippingRange();capture(win,PRE/'Hero_ActualMesh.png');print('RENDERED HERO',flush=True)

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'all'
    if mode=='test':single(DATA[3],size=(1000,900))
    if mode in ['all','individual']:
        for p in DATA:single(p)
    if mode in ['all','hero']:hero()
    if mode in ['all','wire']:
        for i in [3,2,10]:single(DATA[i],True)
