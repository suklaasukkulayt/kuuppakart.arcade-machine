"""Construction Site Essentials — original deterministic mesh + texture authoring.
Authoring axes: X right, -Y front, Z up. All dimensions are metres.
No external models, textures, fonts or random downloads are used.
"""
from __future__ import annotations
import math, json, sys, os
from pathlib import Path
from dataclasses import dataclass, field
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'Source'; TEX=ROOT/'UnityProject/Assets/ConstructionSiteEssentials/Textures'
for p in [SRC,TEX,ROOT/'Exports/GLB',ROOT/'Exports/FBX',ROOT/'Previews/Individual',ROOT/'Previews/Technical',ROOT/'Documentation',ROOT/'Validation']:
    p.mkdir(parents=True,exist_ok=True)

MATS={
'SafetyOrange':((0.95,0.295,0.055),.08,.43,'paint'),
'SignalYellow':((0.98,0.69,0.035),.03,.4,'paint'),
'TealPaint':((0.075,0.34,0.32),.35,.42,'paint'),
'GalvanizedSteel':((.48,.53,.55),.92,.34,'steel'),
'Rubber':((.045,.055,.067),.0,.82,'rubber'),
'Timber':((.60,.39,.205),.0,.78,'wood'),
'KraftPaper':((.72,.64,.47),.0,.87,'paper'),
'Terracotta':((.64,.25,.135),.0,.91,'brick'),
'ReflectiveWhite':((.91,.925,.89),.12,.27,'paint'),
'CharcoalPaint':((.07,.105,.125),.42,.46,'paint'),
'HazardStripes':((1,1,1),.04,.49,'stripe'),
'RoadGraphic':((1,1,1),.04,.43,'road'),
'CautionGraphic':((1,1,1),.0,.51,'caution'),
'BagGraphic':((1,1,1),.0,.88,'bag'),
'WorklightLens':((1,1,1),.08,.21,'led'),
}
# Original, tiny geometric alphabet: image markings only; no font binary dependency.
FONT={
'A':["01110","11011","11011","11111","11011","11011","11011"],
'B':["11110","11011","11011","11110","11011","11011","11110"],
'C':["01111","11000","11000","11000","11000","11000","01111"],
'D':["11110","11011","11011","11011","11011","11011","11110"],
'E':["11111","11000","11000","11110","11000","11000","11111"],
'I':["11111","00100","00100","00100","00100","00100","11111"],
'K':["11011","11010","11100","11100","11110","11011","11011"],
'L':["11000","11000","11000","11000","11000","11000","11111"],
'M':["11011","11111","11111","11011","11011","11011","11011"],
'N':["11011","11111","11111","11111","11011","11011","11011"],
'O':["01110","11011","11011","11011","11011","11011","01110"],
'P':["11110","11011","11011","11110","11000","11000","11000"],
'R':["11110","11011","11011","11110","11100","11010","11011"],
'S':["01111","11000","11000","01110","00011","00011","11110"],
'T':["11111","00100","00100","00100","00100","00100","00100"],
'U':["11011","11011","11011","11011","11011","11011","01110"],
'W':["11011","11011","11011","11011","11111","11111","01010"],
'X':["11011","11011","01110","00100","01110","11011","11011"],
'Y':["11011","11011","01110","00100","00100","00100","00100"],
'2':["01110","11011","00011","00110","01100","11000","11111"],
'5':["11111","11000","11000","11110","00011","00011","11110"],
'0':["01110","11011","11111","11111","11011","11011","01110"],
' ':["00000"]*7}
def pixel_text(draw,text,box,fill):
    x0,y0,x1,y1=box;w=(len(text)*6-1);s=min((x1-x0)/w,(y1-y0)/7);ox=(x0+x1-w*s)/2;oy=(y0+y1-7*s)/2
    for c,ch in enumerate(text):
        for y,line in enumerate(FONT.get(ch,FONT[' '])):
            for x,v in enumerate(line):
                if v=='1': draw.rectangle((round(ox+(c*6+x)*s),round(oy+y*s),round(ox+(c*6+x+1)*s),round(oy+(y+1)*s)),fill=fill)

def textures():
    for j,(name,(col,metal,rough,kind)) in enumerate(MATS.items()):
        n=1024 if kind in ['road','caution','bag','stripe','led'] else 512
        rng=np.random.default_rng(448900+j);raw=rng.normal(0,1,(n,n))
        fine=gaussian_filter(raw,1,mode='wrap');coarse=gaussian_filter(raw,12,mode='wrap');coarse/=max(coarse.std(),1e-6)
        yy,xx=np.mgrid[:n,:n];u=xx/n;v=yy/n
        height=fine*.35+coarse*.05
        strength={'paint':.014,'steel':.05,'rubber':.018,'wood':.07,'paper':.03,'brick':.055}.get(kind,.012)
        mod=1+fine*strength*2+coarse*strength
        if kind=='wood':
            grain=np.sin(2*np.pi*(32*u+1.3*np.sin(2*np.pi*v)+.3*np.sin(8*np.pi*v)))
            mod=1+grain*.09+coarse*.045; height+=grain*.15
        if kind=='steel': mod+=.025*np.sin(2*np.pi*u*168)
        arr=np.clip(np.array(col)[None,None,:]*mod[:,:,None]*255,0,255).astype('uint8')
        im=Image.fromarray(arr);d=ImageDraw.Draw(im)
        dark=(24,32,35); yellow=(246,174,23)
        if kind=='stripe':
            bands=((xx+yy)//256)%2;arr=np.where(bands[:,:,None]==0,np.array(yellow),np.array(dark));im=Image.fromarray(arr.astype('uint8'))
        elif kind=='road':
            d.rectangle((0,0,n,n),fill=yellow);d.rectangle((18,18,n-18,n-18),outline=dark,width=22)
            # Bold directional chevron, authored from simple polygons.
            d.polygon([(160,408),(580,408),(580,220),(872,512),(580,804),(580,616),(160,616)],fill=dark)
        elif kind=='caution':
            d.rectangle((0,0,n,n),fill=yellow);d.rounded_rectangle((18,18,n-18,n-18),32,outline=dark,width=16)
            pixel_text(d,'CAUTION',(65,70,959,185),dark)
            d.polygon([(512,267),(130,849),(894,849)],fill=dark)
            d.polygon([(512,358),(221,801),(803,801)],fill=yellow)
            d.polygon([(478,448),(546,448),(535,661),(489,661)],fill=dark);d.ellipse((478,692,546,760),fill=dark)
            pixel_text(d,'SITE',(325,900,699,960),dark)
        elif kind=='bag':
            d.rectangle((0,0,n,n),fill=(183,163,119));d.rectangle((45,45,n-45,n-45),outline=(36,64,61),width=20)
            pixel_text(d,'DRY MIX',(108,140,916,255),(36,64,61));pixel_text(d,'25',(245,360,779,775),(36,64,61))
            d.line((118,856,906,856),fill=(36,64,61),width=24)
        elif kind=='led':
            d.rectangle((0,0,n,n),fill=(223,228,209))
            for cy in range(128,n,192):
                for cx in range(130,n,190):
                    d.rounded_rectangle((cx-52,cy-48,cx+52,cy+48),12,fill=(111,121,115))
                    d.rectangle((cx-35,cy-31,cx+35,cy+31),fill=(255,234,154))
        im.save(TEX/f'CSE_{name}_BaseColor.png',compress_level=2)
        strengthn={'brick':2.2,'wood':1.0,'paper':1.0,'rubber':.8,'steel':.5,'paint':.25}.get(kind,.12)
        dx=(np.roll(height,-1,1)-np.roll(height,1,1))*strengthn;dy=(np.roll(height,-1,0)-np.roll(height,1,0))*strengthn
        normals=np.stack((-dx,dy,np.ones_like(dx)),2);normals/=np.linalg.norm(normals,axis=2,keepdims=True)
        Image.fromarray(np.uint8(np.clip((normals*.5+.5)*255,0,255))).save(TEX/f'CSE_{name}_Normal.png',compress_level=2)
        r=np.uint8(np.clip((rough+fine*.03)*255,0,255));m=np.full_like(r,round(metal*255))
        Image.fromarray(np.stack([np.full_like(r,255),r,m],2)).save(TEX/f'CSE_{name}_ORM.png',compress_level=2)
        Image.fromarray(np.stack([m,m,m,255-r],2),'RGBA').save(TEX/f'CSE_{name}_MetallicSmoothness.png',compress_level=2)
        if kind=='led':
            a=np.array(im).astype(float)/255; mask=((a[:,:,0]>.9)&(a[:,:,1]>.75)).astype(float)
            em=(a*mask[:,:,None]*255).astype('uint8');Image.fromarray(em).save(TEX/f'CSE_{name}_Emission.png')
    (SRC/'materials.json').write_text(json.dumps({k:{'base_color':v[0],'metallic':v[1],'roughness':v[2],'kind':v[3],'texture_size':1024 if v[3] in ['road','caution','bag','stripe','led'] else 512} for k,v in MATS.items()},indent=2))

@dataclass
class Part:
    name:str; v:np.ndarray; f:list; mat:str; smooth:bool=True; uv:list|None=None; normals:np.ndarray|None=None
    def transform(self,R=None,t=None):
        if R is not None:
            self.v=self.v@np.array(R).T
            if self.normals is not None:self.normals=self.normals@np.array(R).T
        if t is not None:self.v+=np.array(t)
        return self

def rot(axis,a):
    c,s=math.cos(a),math.sin(a)
    return np.array({'x':[[1,0,0],[0,c,-s],[0,s,c]],'y':[[c,0,s],[0,1,0],[-s,0,c]],'z':[[c,-s,0],[s,c,0],[0,0,1]]}[axis])
def recalc(p):
    norms=np.zeros_like(p.v)
    for face in p.f:
        a,b,c=p.v[np.array(face[:3])];n=np.cross(b-a,c-a)
        if np.linalg.norm(n)>1e-12:
            n/=np.linalg.norm(n)
            for i in face:norms[i]+=n
    norms/=np.maximum(np.linalg.norm(norms,axis=1,keepdims=True),1e-10);p.normals=norms
    return p

def box(name,loc,dim,mat,r=.008,seg=2):
    """A closed rounded box with shared vertex indices and analytic normals."""
    half=np.array(dim)/2;r=min(r,float(min(half))*.8)
    axes=[]
    for h in half:
        axes.append(np.unique(np.r_[np.linspace(-h,-h+r,seg+1),np.linspace(h-r,h,seg+1)]))
    verts=[];faces=[];normal=[];look={}
    def vertex(p):
        core=np.clip(p,-half+r,half-r);delta=p-core;n=delta/np.linalg.norm(delta);pos=core+n*r;k=tuple(np.round(pos,9))
        if k not in look:look[k]=len(verts);verts.append(pos);normal.append(n)
        return look[k]
    for axis in range(3):
        others=[i for i in range(3) if i!=axis]
        for sign in [-1,1]:
            a,b=others;grid=[]
            for aa in axes[a]:
                row=[]
                for bb in axes[b]:
                    p=np.zeros(3);p[axis]=sign*half[axis];p[a]=aa;p[b]=bb;row.append(vertex(p))
                grid.append(row)
            for i in range(len(grid)-1):
                for j in range(len(grid[0])-1):
                    f=[grid[i][j],grid[i+1][j],grid[i+1][j+1],grid[i][j+1]]
                    v=np.array([verts[k] for k in f]);n=np.cross(v[1]-v[0],v[2]-v[0])
                    if n[axis]*sign<0:f=f[::-1]
                    faces.append(f)
    return Part(name,np.array(verts),faces,mat,True,normals=np.array(normal)).transform(t=loc)

def lathe(name,profile,mat,n=32,cap=True):
    v=[];f=[];uv=[]
    for rad,z in profile:
        for j in range(n):
            a=2*math.pi*j/n;v.append((rad*math.cos(a),rad*math.sin(a),z))
    for i in range(len(profile)-1):
        for j in range(n):
            f.append([i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j])
            uv.append([(j/n,i/(len(profile)-1)),((j+1)/n,i/(len(profile)-1)),((j+1)/n,(i+1)/(len(profile)-1)),(j/n,(i+1)/(len(profile)-1))])
    if cap:
        f.append(list(range(n-1,-1,-1)));f.append([(len(profile)-1)*n+j for j in range(n)])
        for ring in [0,len(profile)-1]:
            uv.append([(.5+math.cos(2*math.pi*j/n)*.5,.5+math.sin(2*math.pi*j/n)*.5) for j in (range(n-1,-1,-1) if ring==0 else range(n))])
    return recalc(Part(name,np.array(v),f,mat,True,uv=uv))

def cylinder(name,a,b,r,mat,n=16):
    a=np.array(a,float);b=np.array(b,float);length=np.linalg.norm(b-a);d=(b-a)/length
    q=np.array([0,0,1.]) if abs(d[2])<.9 else np.array([0,1.,0]);u=np.cross(q,d);u/=np.linalg.norm(u);w=np.cross(d,u)
    R=np.column_stack([u,w,d]);p=lathe(name,[(r*.86,0),(r,.003 if length>.015 else length*.15),(r,length-.003 if length>.015 else length*.85),(r*.86,length)],mat,n)
    return p.transform(R,a)

def tube(name,path,r,mat,n=10):
    path=np.array(path,float);closed=np.linalg.norm(path[0]-path[-1])<1e-8
    if closed:path=path[:-1]
    # Use the best-fit path plane normal, avoiding frame flips at corners.
    _,_,vh=np.linalg.svd(path-path.mean(axis=0),full_matrices=False)
    ref=vh[-1];v=[];f=[];count=len(path)
    for i,c in enumerate(path):
        d=path[(i+1)%count]-path[(i-1)%count] if closed else path[min(i+1,count-1)]-path[max(i-1,0)]
        d/=np.linalg.norm(d);u=np.cross(ref,d);u/=np.linalg.norm(u);w=np.cross(d,u)
        for j in range(n):v.append(c+r*(math.cos(2*math.pi*j/n)*u+math.sin(2*math.pi*j/n)*w))
    for i in range(count if closed else count-1):
        k=(i+1)%count
        for j in range(n):f.append([i*n+j,i*n+(j+1)%n,k*n+(j+1)%n,k*n+j])
    if not closed:f.extend([list(range(n-1,-1,-1)),[(count-1)*n+j for j in range(n)]])
    return recalc(Part(name,np.array(v),f,mat))

def torus(name,center,major,minor,mat,N=24,n=6,axis='z'):
    v=[];f=[]
    for i in range(N):
        a=2*math.pi*i/N
        for j in range(n):
            b=2*math.pi*j/n;v.append(((major+minor*math.cos(b))*math.cos(a),(major+minor*math.cos(b))*math.sin(a),minor*math.sin(b)))
    for i in range(N):
        for j in range(n):f.append([i*n+j,((i+1)%N)*n+j,((i+1)%N)*n+(j+1)%n,i*n+(j+1)%n])
    p=recalc(Part(name,np.array(v),f,mat));R=rot('y',math.pi/2) if axis=='x' else rot('x',math.pi/2) if axis=='y' else None
    return p.transform(R,center)

def ellipse_ring(name,rx,ry,innerx,innery,z,t,mat,n=48):
    v=[];f=[]
    for ax,ay,zz in [(rx,ry,z),(rx,ry,z+t),(innerx,innery,z+t),(innerx,innery,z)]:
        for i in range(n):a=2*math.pi*i/n;v.append((ax*math.cos(a),ay*math.sin(a),zz))
    for ring in range(4):
        nextg=(ring+1)%4
        for i in range(n):f.append([ring*n+i,ring*n+(i+1)%n,nextg*n+(i+1)%n,nextg*n+i])
    return recalc(Part(name,np.array(v),f,mat))

def panel(name,center,w,h,mat):
    x,y,z=center;v=np.array([[x-w/2,y,z-h/2],[x+w/2,y,z-h/2],[x+w/2,y,z+h/2],[x-w/2,y,z+h/2]],float)
    u=w/h if mat=='HazardStripes' else 1
    return Part(name,v,[[0,1,2,3]],mat,False,uv=[[(0,0),(u,0),(u,1),(0,1)]],normals=np.tile([0.,-1.,0.],(4,1)))

def ring_rect(w,l,r,z,segments=4):
    points=[]
    for cx,cy,start in [(w/2-r,l/2-r,0),(-w/2+r,l/2-r,90),(-w/2+r,-l/2+r,180),(w/2-r,-l/2+r,270)]:
        for j in range(segments):
            a=math.radians(start+j*90/(segments-1));points.append((cx+r*math.cos(a),cy+r*math.sin(a),z))
    return points

def shell_rings(name,rings,mat,cap_start=True,cap_end=True):
    n=len(rings[0]);v=np.array([p for ring in rings for p in ring]);f=[]
    for i in range(len(rings)-1):
        for j in range(n):f.append([i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j])
    if cap_start:f.append(list(range(n-1,-1,-1)))
    if cap_end:f.append([(len(rings)-1)*n+j for j in range(n)])
    return recalc(Part(name,v,f,mat))

PROPS=[]
def finish(name,display,parts,notes):
    # Consistent ground-centred origin, applied transforms, original dimensions.
    allv=np.concatenate([p.v for p in parts]);lo=allv.min(0);hi=allv.max(0);offset=np.array([-(lo[0]+hi[0])/2,-(lo[1]+hi[1])/2,-lo[2]])
    for p in parts:p.transform(t=offset)
    PROPS.append(dict(name=name,display=display,parts=parts,notes=notes))

def create_props():
    P=[]
    P.append(box('Weighted_octagonal_base',(0,0,.036),(.38,.38,.072),'Rubber',.035,2))
    # Alternating separate conical bands share coincident seams, not overlaid shells.
    profile=[(.143,.07),(.142,.082),(.120,.18),(.103,.25),(.082,.35),(.065,.43),(.042,.53),(.04,.575)]
    for i in range(len(profile)-1):
        mat='ReflectiveWhite' if i in [2,4] else 'SafetyOrange'
        P.append(lathe(f'Cone_band_{i+1}',profile[i:i+2],mat,32,True))
    P.append(ellipse_ring('Open_top_rim',.041,.041,.026,.026,.575,.012,'SafetyOrange',32))
    P.append(lathe('Top_dark_insert',[(.026,.568),(.026,.573)],'Rubber',32,True))
    finish('TrafficCone','Traffic cone',P,'0.59 m cone; two white bands; weighted rubber base. White material is not a simulated retroreflector.')

    P=[]
    for x in [-.78,.78]:
        P.append(box('Cross_foot',(x,0,.038),(.15,.60,.076),'Rubber',.027))
        P.append(box('Support_post',(x,0,.52),(.066,.068,.98),'SafetyOrange',.009))
        for z in [.38,.85]:P.append(cylinder('Fastener',(x,-.062,z),(x,-.072,z),.016,'GalvanizedSteel',12))
    P.append(box('Panel_frame',(0,-.008,.66),(1.85,.084,.50),'SafetyOrange',.035))
    P.append(box('Reflector_back',(0,-.059,.66),(1.72,.024,.385),'ReflectiveWhite',.008))
    P.append(panel('Diagonal_warning_stripes',(0,-.073,.66),1.65,.32,'HazardStripes'))
    P.append(panel('Rear_warning_stripes',(0,-.038,.66),1.65,.32,'HazardStripes').transform(rot('z',math.pi)))
    finish('SafetyBarrier','Safety barrier',P,'Freestanding striped barrier with two weighted feet, rear panel and fasteners.')

    P=[];n=40;rings=[]
    # Pole is separate to avoid collapsed zero-area faces.
    for t in np.linspace(.04,math.pi/2,11):rings.append([( .143*math.sin(t)*math.cos(2*math.pi*j/n),.176*math.sin(t)*math.sin(2*math.pi*j/n),.055+.17*math.cos(t)) for j in range(n)])
    for t in np.linspace(math.pi/2,.04,11):rings.append([(.135*math.sin(t)*math.cos(2*math.pi*j/n),.168*math.sin(t)*math.sin(2*math.pi*j/n),.055+.162*math.cos(t)) for j in range(n)])
    p=shell_rings('Double_walled_shell',rings,'SignalYellow');# reverse to outward: ring path runs top->base->inner top
    p.f=[f[::-1] for f in p.f];recalc(p);P.append(p)
    P.append(ellipse_ring('Wide_protective_brim',.168,.219,.131,.163,.04,.016,'SignalYellow',48))
    P.append(ellipse_ring('Inner_suspension_band',.130,.160,.118,.148,.013,.026,'CharcoalPaint',40))
    for x in [-.055,0,.055]:
        path=[]
        for y in np.linspace(-.13,.13,15):
            z=.055+.170*math.sqrt(max(0,1-(x/.143)**2-(y/.176)**2))+.003
            path.append((x,y,z))
        P.append(tube('Crown_ridge',path,.0055,'SignalYellow',8))
    for side in [-1,1]:
        for y in [-.061,-.025,.012,.049]:
            p=box('Vent_inset',(side*.130,y,.11),(.008,.022,.016),'CharcoalPaint',.003,1);P.append(p)
    finish('HardHat','Hard hat',P,'Hollow double-wall shell, broad brim, suspension band and three crown ridges. Decorative prop, not safety equipment.')

    P=[]
    rings=[ring_rect(.34,.52,.07,.40),ring_rect(.40,.61,.085,.43),ring_rect(.63,.86,.13,.74),ring_rect(.61,.84,.125,.757),ring_rect(.58,.80,.115,.735),ring_rect(.34,.53,.065,.445)]
    P.append(shell_rings('Formed_open_tray',rings,'TealPaint'))
    # Rim is a closed raised lip using ring cross-sections.
    rr=ring_rect(.62,.85,.128,.747);P.append(tube('Rolled_tray_rim',rr+[rr[0]],.011,'CharcoalPaint',8))
    for x in [-.195,.195]:
        path=[(x,-.53,.215),(x,-.35,.40),(x,.05,.39),(x,.43,.51),(x,.80,.62)]
        P.append(tube('Main_tubular_frame',path,.023,'CharcoalPaint',12))
        P.append(tube('Rear_support_leg',[(x,.05,.39),(x,.17,.055),(x,.37,.055),(x,.34,.44)],.02,'CharcoalPaint',12))
        P.append(cylinder('Rubber_handle',(x,.65,.575),(x,.845,.645),.029,'Rubber',16))
    P.append(cylinder('Wheel_axle',(-.27,-.49,.202),(.27,-.49,.202),.019,'GalvanizedSteel',16))
    P.append(torus('Pneumatic_tire',(0,-.49,.202),.142,.058,'Rubber',40,10,'x'))
    P.append(cylinder('Orange_wheel_hub',(-.058,-.49,.202),(.058,-.49,.202),.111,'SafetyOrange',28))
    for s in [-1,1]:P.append(cylinder('Axle_cap',(s*.06,-.49,.202),(s*.072,-.49,.202),.028,'GalvanizedSteel',12))
    for i in range(20):
        a=2*math.pi*i/20; c=(0,-.49+.197*math.sin(a),.202+.197*math.cos(a));p=box('Tire_tread',c,(.071,.025,.010),'Rubber',.002,1)
        R=rot('x',-a);p.transform(t=-np.array(c)).transform(R,c);P.append(p)
    P.append(cylinder('Frame_cross_brace',(-.19,.25,.10),(.19,.25,.10),.018,'GalvanizedSteel',12))
    finish('Wheelbarrow','Wheelbarrow',P,'Open teal tray, tubular undercarriage, treaded wheel, two support legs and rubber grips; static assembly.')

    P=[]
    outline=[(0,0),(.08,.045),(.125,.11),(.132,.28),(.09,.32),(-.09,.32),(-.132,.28),(-.125,.11),(-.08,.045)]
    v=[]
    for depth in [0,.009]:
        for x,z in outline:v.append((x, -.035*(1-(x/.145)**2)-.025*z/.32+depth,z))
    v+=[(0,-.055,.19),(0,-.046,.19)];n=len(outline);f=[]
    for i in range(n):
        f.append([2*n,i,(i+1)%n]);f.append([2*n+1,(i+1)%n+n,i+n]);f.append([i,i+n,(i+1)%n+n,(i+1)%n])
    p=recalc(Part('Curved_spade_blade',np.array(v),f,'GalvanizedSteel'));P.append(p)
    P.append(cylinder('Blade_socket',(0,-.015,.24),(0,.025,.44),.027,'CharcoalPaint',20))
    P.append(cylinder('Timber_shaft',(0,.018,.40),(0,.095,1.01),.021,'Timber',20))
    P.append(tube('D_grip_frame',[(0,.095,.96),(-.075,.104,1.03),(-.075,.11,1.155),(.075,.11,1.155),(.075,.104,1.03),(0,.095,.96)],.016,'SafetyOrange',12))
    P.append(cylinder('D_grip_rubber',(-.070,.11,1.151),(.070,.11,1.151),.021,'Rubber',16))
    finish('Shovel','Shovel',P,'Curved steel blade, timber shaft, orange D grip and black grip sleeve.')

    P=[];v=[];f=[];N=40;K=18
    def sp(x,e):return math.copysign(abs(x)**e,x)
    for k in range(1,K):
        phi=-math.pi/2+k*math.pi/K
        for j in range(N):
            a=2*math.pi*j/N;x=.25*sp(math.cos(phi),.48)*sp(math.cos(a),.48);y=.165*sp(math.cos(phi),.48)*sp(math.sin(a),.48);z=.076+.074*sp(math.sin(phi),.58)
            z+=.0025*math.sin(a*5+.4)*math.cos(phi)*math.sin(phi*3)
            v.append((x,y,z))
    v.append((0,0,.002));bottom=len(v)-1;v.append((0,0,.15));top=len(v)-1
    for k in range(K-2):
        for j in range(N):f.append([k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j])
    for j in range(N):f.append([bottom,(j+1)%N,j]);f.append([top,(K-2)*N+j,(K-2)*N+(j+1)%N])
    P.append(recalc(Part('Filled_kraft_sack',np.array(v),f,'KraftPaper')))
    for y in [-.165,.165]:
        P.append(box('Folded_seam',(0,y,.074),(.474,.018,.026),'KraftPaper',.006))
        for x in np.linspace(-.21,.21,22):P.append(cylinder('Stitch',(x,y-.005,.083),(x,y+.005,.083),.0012,'Timber',6))
    # Label lies on the flat central area of the sack top.
    p=panel('Mix_label',(0,0,0),.255,.20,'BagGraphic');p.transform(rot('x',-math.pi/2),(0,0,.152));P.append(p)
    finish('CementBag','Cement bag',P,'Soft filled kraft sack with folded ends, geometric stitches and original DRY MIX / 25 marking; no brand.')

    P=[]
    P.append(box('Lower_case',(0,0,.118),(.46,.235,.236),'SafetyOrange',.023))
    P.append(box('Case_lid',(0,0,.267),(.473,.247,.082),'CharcoalPaint',.021))
    P.append(box('Lid_seal',(0,0,.225),(.468,.242,.014),'Rubber',.006))
    P.append(tube('Carry_handle',[(-.096,0,.305),(-.096,0,.38),(-.072,0,.397),(.072,0,.397),(.096,0,.38),(.096,0,.305)],.017,'CharcoalPaint',12))
    for x in [-.144,.144]:
        P.append(box('Latch_plate',(x,-.126,.242),(.051,.022,.090),'GalvanizedSteel',.006))
        P.append(box('Latch_clasp',(x,-.144,.245),(.029,.022,.043),'CharcoalPaint',.006))
        P.append(cylinder('Rear_hinge',(x-.034,.122,.236),(x+.034,.122,.236),.014,'GalvanizedSteel',12))
    for x in [-.215,.215]:
        for y in [-.098,.098]:P.append(box('Impact_corner',(x,y,.044),(.04,.035,.080),'Rubber',.010))
    for x in [-.16,-.08,0,.08,.16]:P.append(box('Lid_rib',(x,.065,.306),(.019,.092,.009),'CharcoalPaint',.003,1))
    finish('Toolbox','Toolbox',P,'Orange protective case, dark ribbed lid, steel latches, rear hinges and raised carry handle. Lid is not animated.')

    P=[]
    P.append(box('Weighted_sign_base',(0,0,.045),(.45,.44,.09),'Rubber',.043))
    P.append(cylinder('Steel_post',(0,0,.055),(0,0,1.62),.024,'GalvanizedSteel',20))
    plate=box('Diamond_plate',(0,0,0),(.56,.032,.56),'SignalYellow',.018)
    plate.transform(rot('y',math.pi/4),(0,-.035,1.48));P.append(plate)
    # Graphic is square and rotates with the diamond; arrow rotated back by image-independent geometry not needed.
    p=panel('Direction_graphic',(0,-.054,1.48),.525,.525,'RoadGraphic');p.transform(t=(0,0,-1.48)).transform(rot('y',math.pi/4),(0,0,1.48));P.append(p)
    for z in [1.18,1.78]:P.append(cylinder('Plate_bolt',(0,-.062,z),(0,-.075,z),.012,'GalvanizedSteel',12))
    for z in [1.33,1.6]:P.append(box('Mounting_bracket',(0,.015,z),(.18,.07,.035),'CharcoalPaint',.004))
    finish('RoadSign','Road sign',P,'Weighted-base diamond direction sign with original generic arrow graphic. Not a certified jurisdiction-specific traffic sign.')

    P=[]
    for a in [0,2*math.pi/3,4*math.pi/3]:
        end=(.41*math.cos(a),.41*math.sin(a),.038)
        P.append(cylinder('Tripod_leg',(0,0,.43),end,.022,'CharcoalPaint',14));P.append(box('Rubber_foot',end,(.10,.08,.055),'Rubber',.017))
        P.append(cylinder('Leg_brace',(0,0,.2),(.27*math.cos(a),.27*math.sin(a),.16),.012,'GalvanizedSteel',10))
    P.append(cylinder('Lower_column',(0,0,.21),(0,0,.93),.030,'CharcoalPaint',20));P.append(cylinder('Telescopic_column',(0,0,.85),(0,0,1.45),.021,'GalvanizedSteel',20))
    P.append(cylinder('Height_lock',(0,0,.87),(0,-.060,.87),.019,'SafetyOrange',16));P.append(box('Cross_head_bar',(0,0,1.41),(.67,.048,.04),'CharcoalPaint',.006))
    for x in [-.22,.22]:
        P.append(tube('U_mount',[(x-.14,0,1.47),(x-.14,0,1.34),(x+.14,0,1.34),(x+.14,0,1.47)],.012,'CharcoalPaint',8))
        P.append(box('Floodlight_housing',(x,-.012,1.565),(.255,.112,.23),'SafetyOrange',.023))
        P.append(box('Lens_gasket',(x,-.074,1.565),(.223,.022,.199),'Rubber',.012))
        P.append(panel('LED_lens',(x,-.087,1.565),.197,.17,'WorklightLens'))
        P.append(tube('Upper_handle',[(x-.08,.015,1.67),(x-.08,.015,1.73),(x+.08,.015,1.73),(x+.08,.015,1.67)],.009,'CharcoalPaint',8))
        for dx in [-.08,-.04,0,.04,.08]:P.append(box('Cooling_fin',(x+dx,.054,1.565),(.012,.035,.165),'CharcoalPaint',.003,1))
        for sx in [-1,1]:P.append(cylinder('Pivot_knob',(x+sx*.127,0,1.53),(x+sx*.147,0,1.53),.019,'CharcoalPaint',12))
    P.append(tube('Short_power_lead',[(.07,.07,.8),(.1,.06,.64),(.06,.09,.59),(.008,.07,.66),(.03,.04,.8)],.005,'Rubber',8))
    finish('PortableWorkLight','Portable work light',P,'Twin LED-style heads on a telescopic tripod; emissive material included. No real-time Light component or cable physics.')

    P=[];rng=np.random.default_rng(283)
    for layer in range(3):
        for i in range(3):
            for j in range(2):
                # Closed mesh with a true depressed frog on the upper face.
                rings=[ring_rect(.211,.099,.012,.002),ring_rect(.221,.109,.012,.010),ring_rect(.221,.109,.012,.060),ring_rect(.211,.099,.010,.068),ring_rect(.155,.044,.009,.068),ring_rect(.144,.033,.009,.055)]
                p=shell_rings(f'Brick_{layer}_{i}_{j}',rings,'Terracotta');p.transform(rot('z',float(rng.uniform(-.016,.016))),((i-1)*.226,(j-.5)*.115,layer*.073));P.append(p)
    finish('BrickStack','Stack of bricks',P,'18 individually editable bricks with chamfered edges and inset frogs, arranged in three layers.')

    P=[]
    for x in [-.62,.62]:P.append(box('Timber_dunnage',(x,0,.025),(.075,.24,.05),'Timber',.008))
    centres=[(-.050,.071),(0,.071),(.050,.071),(-.025,.112),(.025,.112),(0,.153)]
    # Six solid rods in triangular packing; explicit listing matches geometry.
    for idx,(y,z) in enumerate(centres):
        length=2.03+(.04 if idx%2 else 0);P.append(cylinder(f'Rebar_{idx+1}',(-length/2,y,z),(length/2,y,z),.019,'GalvanizedSteel',12))
        for k,x in enumerate(np.linspace(-.97,.97,18)):
            P.append(torus(f'Raised_rib_{idx+1}_{k+1}',(x,y,z),.0192,.0028,'GalvanizedSteel',8,3,'x'))
    for x in [-.65,.65]:
        path=[(x,-.078,.06),(x,.077,.06),(x,.061,.112),(x,.019,.177),(x,-.019,.177),(x,-.061,.112),(x,-.078,.06)]
        P.append(tube('Bundle_tie',path,.004,'CharcoalPaint',6))
    finish('RebarBundle','Rebar bundle',P,'Six ribbed 2 m steel bars in triangular packing, two ties and two timber dunnage blocks; static assembly.')

    P=[];ang=.30
    for side in [-1,1]:
        pieces=[]
        pieces.append(box('Lower_warning_board',(0,0,.325),(.38,.034,.51),'SignalYellow',.018))
        for x in [-.167,.167]:pieces.append(box('Handle_side',(x,0,.618),(.048,.034,.153),'SignalYellow',.01))
        pieces.append(box('Top_handle_bridge',(0,0,.703),(.38,.039,.045),'SignalYellow',.014))
        for x in [-.151,.151]:pieces.append(box('Splayed_foot',(x,0,.047),(.07,.08,.054),'Rubber',.011))
        decal=panel('Caution_face',(0,-.019 if side==-1 else .019,.335),.321,.417,'CautionGraphic')
        if side==1:
            # Rear face turns outward while preserving UV reading.
            decal.v[:,0]*=-1;decal.normals[:]=[0,1,0]
        pieces.append(decal)
        for p in pieces:p.transform(t=(0,0,-.725)).transform(rot('x',side*ang),(0,0,.725));P.append(p)
    P.append(cylinder('Folding_hinge',(-.18,0,.722),(.18,0,.722),.023,'CharcoalPaint',20))
    for x in [-.128,.128]:P.append(cylinder('Spread_limiter',(x,-.13,.28),(x,.13,.28),.008,'CharcoalPaint',10))
    finish('CautionSign','Caution sign',P,'Double-sided folding A-frame sign with an open carry handle, rubber feet and original CAUTION marking; static assembly.')


def pack_faces(prop):
    """Render/export-ready split vertices, UV0 material tiling, UV1 unique chart packing."""
    verts=[];norms=[];uv0=[];faces=[];face_mats=[];charts=[];source=[]
    for part in prop['parts']:
        if part.normals is None:recalc(part)
        source.append({'name':part.name,'vertices':part.v.round(8).tolist(),'faces':part.f,'material':part.mat,'smooth':part.smooth,'normals':part.normals.round(7).tolist()})
        for fi,face in enumerate(part.f):
            pos=part.v[face];n=np.cross(pos[1]-pos[0],pos[2]-pos[0]);ln=np.linalg.norm(n)
            if ln<1e-12:raise ValueError(f'Degenerate source face: {prop["name"]}/{part.name}/{fi}')
            n/=ln;edges=np.roll(pos,-1,axis=0)-pos;ei=np.argmax(np.linalg.norm(edges,axis=1));a=edges[ei];a=a/np.linalg.norm(a);b=np.cross(n,a);b/=max(np.linalg.norm(b),1e-10)
            planar=np.column_stack([pos@a,pos@b]);planar-=planar.min(0);dims=np.maximum(planar.max(0),.00015)
            if dims[1]>dims[0]:planar=planar[:,::-1];dims=dims[::-1]
            begin=len(verts);verts.extend(pos);norms.extend(part.normals[face] if part.smooth else np.tile(n,(len(face),1)))
            if part.uv is not None:uv0.extend(part.uv[fi])
            else:
                axis=int(np.argmax(abs(n)));aa,bb=[i for i in range(3) if i!=axis]
                uv0.extend(np.column_stack([pos[:,aa]*2,pos[:,bb]*2]))
            faces.append(list(range(begin,begin+len(face))));face_mats.append(part.mat);charts.append((planar,dims,begin,len(face)))
    margin=.0018
    def attempt(scale):
        order=sorted(range(len(charts)),key=lambda i:charts[i][1][1],reverse=True);shelves=[];positions={};y=0
        for i in order:
            dims=charts[i][1]*scale+margin*2;w,h=dims
            if w>1 or h>1:return None
            placed=False
            for shelf in shelves:
                if h<=shelf[1]+1e-9 and shelf[2]+w<=1:
                    positions[i]=(shelf[2]+margin,shelf[0]+margin);shelf[2]+=w;placed=True;break
            if not placed:
                if y+h>1:return None
                positions[i]=(margin,y+margin);shelves.append([y,h,w]);y+=h
        return positions
    lo,hi=0.,2/max(float(np.max(ch[1])) for ch in charts)
    for _ in range(32):
        mid=(lo+hi)/2
        if attempt(mid) is not None:lo=mid
        else:hi=mid
    scale=lo*.999;placements=attempt(scale)
    if placements is None:raise ValueError('UV packing failed')
    uv1=np.zeros((len(verts),2),float)
    for i,(planar,dims,begin,count) in enumerate(charts):uv1[begin:begin+count]=planar*scale+placements[i]
    mats=list(dict.fromkeys(face_mats));tris=[];tri_m=[]
    for face,mat in zip(faces,face_mats):
        for k in range(1,len(face)-1):tris.append([face[0],face[k],face[k+1]]);tri_m.append(mats.index(mat))
    prop.update(vertices=np.array(verts),normals=np.array(norms),uv0=np.array(uv0),uv1=uv1,faces=faces,triangles=np.array(tris),tri_material=np.array(tri_m),materials=mats,source=source)
    prop['dimensions']=np.ptp(prop['vertices'],axis=0).tolist()
    prop['stats']={'triangles':len(tris),'source_vertices':sum(len(p.v) for p in prop['parts']),'render_vertices':len(verts),'material_slots':len(mats),'components':len(prop['parts']),'uv_channels':2,'uv1_chart_margin':margin,'dimensions_xyz_m':prop['dimensions']}

def save_data():
    data=[]
    for p in PROPS:
        pack_faces(p)
        item={k:p[k] for k in ['name','display','notes','stats','materials','source']}
        for k in ['vertices','normals','uv0','uv1','triangles','tri_material']:item[k]=p[k].round(7).tolist() if p[k].dtype.kind=='f' else p[k].tolist()
        item['faces']=p['faces']; data.append(item)
        print(p['name'],p['stats'],flush=True)
    (SRC/'mesh_data.json').write_text(json.dumps(data,separators=(',',':')))
    (ROOT/'Validation/geometry_inventory.json').write_text(json.dumps([{k:p[k] for k in ['name','display','notes','stats','materials']} for p in PROPS],indent=2))
    return data

if __name__=='__main__':
    textures();create_props();save_data(); print('AUTHORING_COMPLETE',flush=True)
