"""Rebuild archives for a complete Construction Site Essentials master delivery.
Run: python Source/package_delivery.py
No publishing/uploading occurs. Must be run in the full master, not source-only ZIP.
Checks local files, adds missing metadata, builds source archive and conventional
.unitypackage, validates, then writes checksums and the outer ZIP next to this root.
"""
from __future__ import annotations
import ast,csv,hashlib,io,json,os,re,shutil,subprocess,sys,tarfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
ASSET=ROOT/'UnityProject/Assets/ConstructionSiteEssentials'
STAMP=1789430400
NAME='ConstructionSiteEssentials_1.0.0'
EXCLUDE={'__pycache__','.DS_Store'}

def items(root):
    return sorted(p for p in root.rglob('*') if p.is_file() and not any(x in EXCLUDE for x in p.parts) and p.suffix not in ['.pyc','.blend1'])
def meta_all():
    for item in [ASSET,*sorted(ASSET.rglob('*'))]:
        if item.name.endswith('.meta') or any(x in EXCLUDE for x in item.parts):continue
        path=Path(str(item)+'.meta')
        if path.exists():continue
        name=str(item.relative_to(ASSET)).replace('\\','/');guid=hashlib.md5(('CSE_1.0.0/'+name).encode()).hexdigest()
        text='fileFormatVersion: 2\nguid: '+guid+'\n'
        if item.is_dir():text+='folderAsset: yes\n'
        kind='MonoImporter' if item.suffix=='.cs' else 'TextScriptImporter' if item.suffix in ['.txt','.md','.json','.csv'] else 'DefaultImporter'
        text+=kind+':\n  externalObjects: {}\n'
        if kind=='MonoImporter':text+='  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n'
        text+='  userData: \n  assetBundleName: \n  assetBundleVariant: \n';path.write_text(text)

def source_bundle():
    folder=ASSET/'Source';folder.mkdir(exist_ok=True)
    start='''Construction Site Essentials — editable source bundle

Extract into a new writable folder. It should contain Source/ and Validation/.
To run Blender reconstruction, copy the installed package Textures folder to:
  UnityProject/Assets/ConstructionSiteEssentials/Textures
inside that extracted working folder. Then run:
  blender --background --python Source/build_blender.py
The script creates Source/Blender/ConstructionSiteEssentials.blend.
Blender 4.2+ is the intended target; this delivery was generated with Blender 5.1.2 and includes the saved .blend/native exports.

This source bundle does not duplicate all runtime FBX/GLB/material/prefab assets.
For the full non-Blender rebuild and package_delivery.py, work from the complete
master ZIP or restore the complete Unity Assets folder, exports and documentation.
No library binaries or font files are bundled. Read SOURCE_WORKFLOW.md and LICENSE.txt.
'''
    with zipfile.ZipFile(folder/'ConstructionSiteEssentials_source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('START_HERE.txt',start)
        for path in items(ROOT/'Source'):z.write(path,str(path.relative_to(ROOT)))
        z.write(ROOT/'Validation/validate_pack.py','Validation/validate_pack.py')
        for name in ['SOURCE_WORKFLOW.md','PROVENANCE_AND_OWNERSHIP.md','Third-Party Notices.txt']:z.write(ROOT/'Documentation'/name,name)
        z.write(ROOT/'LICENSE.txt','LICENSE.txt')
    print('SOURCE_BUNDLE',flush=True)

def unity_package():
    path=ROOT/(NAME+'.unitypackage')
    with tarfile.open(path,'w:gz',compresslevel=6,format=tarfile.USTAR_FORMAT) as tar:
        for item in [ASSET,*sorted(ASSET.rglob('*'))]:
            if item.name.endswith('.meta') or any(x in EXCLUDE for x in item.parts):continue
            meta=Path(str(item)+'.meta');text=meta.read_text();guid=re.search(r'^guid: ([0-9a-f]{32})$',text,re.M).group(1)
            values={'asset.meta':meta.read_bytes(),'pathname':str(item.relative_to(ROOT/'UnityProject')).replace('\\','/').encode()}
            if item.is_file():values['asset']=item.read_bytes()
            for suffix,contents in values.items():
                info=tarfile.TarInfo(guid+'/'+suffix);info.size=len(contents);info.mtime=STAMP;info.mode=0o644;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(contents))
    with tarfile.open(path,'r:gz') as tar:
        assert len(tar.getmembers())>300
        # Reading all regular entries forces gzip CRC checks.
        for entry in tar:
            if entry.isfile():tar.extractfile(entry).read()
    print('UNITYPACKAGE',path.stat().st_size,flush=True)

def inventory():
    exclusions={'FILE_MANIFEST_SHA256.csv','FILE_LIST.txt'}
    with (ROOT/'FILE_MANIFEST_SHA256.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['relative_path','size_bytes','sha256'])
        for path in items(ROOT):
            if path.name in exclusions:continue
            writer.writerow([str(path.relative_to(ROOT)).replace('\\','/'),path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest()])
    paths=items(ROOT);lines=['CONSTRUCTION SITE ESSENTIALS — COMPLETE FILE LIST','',
        'File sizes are bytes. SHA-256 hashes are in FILE_MANIFEST_SHA256.csv.',
        'Manifest/list exclude their own content hashes to avoid self-referential hashes.',
        'UnityProject is an Assets-only scaffold. Blender 5.1.2 source generation and Unity 6.0.4f1 Built-In import checks are recorded in the included reports; URP and publisher review remain pending.','']
    for path in paths:lines.append(f'{path.stat().st_size:>12,}  {str(path.relative_to(ROOT))}')
    (ROOT/'FILE_LIST.txt').write_text('\n'.join(lines)+'\n')

def outer_zip():
    archive=ROOT.parent/(NAME+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for path in items(ROOT):z.write(path,str(Path(ROOT.name)/path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(items(ROOT))
    sha=hashlib.sha256(archive.read_bytes()).hexdigest();Path(str(archive)+'.sha256').write_text(sha+'  '+archive.name+'\n')
    result={'archive':str(archive),'size_bytes':archive.stat().st_size,'sha256':sha,'file_count':len(items(ROOT)),
        'unitypackage':str(ROOT/(NAME+'.unitypackage')),'validation':json.loads((ROOT/'Validation/validation_report.json').read_text())['summary']}
    (ROOT.parent/'CSE_DELIVERY_RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)

def main():
    if len(list((ASSET/'Models').glob('*.fbx')))!=12:raise RuntimeError('Run this from the complete master delivery, with 12 Unity FBX files.')
    for path in [*ROOT.glob('Source/*.py'),ROOT/'Validation/validate_pack.py']:ast.parse(path.read_text(),filename=str(path))
    for path in ROOT.rglob('__pycache__'):shutil.rmtree(path)
    source_bundle();meta_all();unity_package()
    subprocess.run([sys.executable,str(ROOT/'Validation/validate_pack.py')],check=True,cwd=ROOT)
    summary=json.loads((ROOT/'Validation/validation_report.json').read_text())['summary']
    note='# Local and external checks at delivery\n\n'+summary['status']+f"\n\n{summary['passed']} checks passed, {summary['failed']} failed. Blender 5.1.2 FBX re-import evidence is in Validation/blender_reimport_report.json. Unity 6.0.4f1 Built-In compilation/import/setup/demo evidence is in Documentation/UnityImportReport.txt. URP, manual visual/lightmap/device review, Khronos validation and publisher approval remain pending.\n"
    (ASSET/'Documentation/LOCAL_CHECKS.md').write_text(note)
    meta_all();unity_package()
    # Recheck the final package including the local-status documentation.
    subprocess.run([sys.executable,str(ROOT/'Validation/validate_pack.py')],check=True,cwd=ROOT)
    inventory();outer_zip()
if __name__=='__main__':main()
