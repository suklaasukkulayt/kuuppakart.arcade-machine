"""Deterministic Unity asset serialization and .unitypackage assembly helpers.
Requires an actual Unity Editor smoke test before submission; see documentation.
"""
from __future__ import annotations
import json,hashlib,shutil,sys,math,re
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
ROOT=Path(__file__).resolve().parent.parent;ASSET=ROOT/'UnityProject/Assets/ConstructionSiteEssentials'
DATA=json.loads((ROOT/'Source/mesh_data.json').read_text());MATS=json.loads((ROOT/'Source/materials.json').read_text())
for d in ['Models','Materials/URP','Materials/BuiltIn','Prefabs','Demo','Editor','Documentation']:(ASSET/d).mkdir(parents=True,exist_ok=True)
HEAD='%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n'

def guid(path):return hashlib.md5(('CSE_1.0.0/'+str(path).replace('\\','/')).encode()).hexdigest()
def rel(p):return str(p.relative_to(ASSET))
def meta(path,body,folder=False):
    Path(str(path)+'.meta').write_text('fileFormatVersion: 2\nguid: '+guid(rel(path))+'\n'+('folderAsset: yes\n' if folder else '')+body)
def simplemeta(path,importer='DefaultImporter'):
    meta(path,f'{importer}:\n  externalObjects: {{}}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n')
def vec(v):return '{x: %.8g, y: %.8g, z: %.8g}'%tuple(v)
def quat(v):return '{x: %.8g, y: %.8g, z: %.8g, w: %.8g}'%tuple(v)
def ref_mat(name,pipe='URP'):return '{fileID: 2100000, guid: '+guid('Materials/'+pipe+'/CSE_'+name+'.mat')+', type: 2}'
def ref_mesh(p):return '{fileID: 4300000, guid: '+guid('Models/CSE_'+p['name']+'.fbx')+', type: 3}'
def tex_ref(name,kind):return '{fileID: 2800000, guid: '+guid('Textures/CSE_'+name+'_'+kind+'.png')+', type: 3}'

def material(name,pipe,spec):
    path=ASSET/'Materials'/pipe/f'CSE_{name}.mat';urp=pipe=='URP';shader='{fileID: 4800000, guid: 933532a4fcc9baf4fa0491de14d08ed7, type: 3}' if urp else '{fileID: 46, guid: 0000000000000000f000000000000000, type: 0}'
    keys=['_NORMALMAP','_METALLICSPECGLOSSMAP' if urp else '_METALLICGLOSSMAP']
    if name=='WorklightLens':keys.append('_EMISSION')
    text=HEAD+f'''--- !u!21 &2100000
Material:
  serializedVersion: 8
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_Name: CSE_{name}
  m_Shader: {shader}
  m_Parent: {{fileID: 0}}
  m_ModifiedSerializedProperties: 0
  m_ValidKeywords:
'''+''.join('  - '+x+'\n' for x in keys)+'''  m_InvalidKeywords: []
  m_LightmapFlags: 4
  m_EnableInstancingVariants: 1
  m_DoubleSidedGI: 0
  m_CustomRenderQueue: -1
  stringTagMap: {}
  disabledShaderPasses: []
  m_LockedProperties: 
  m_SavedProperties:
    serializedVersion: 3
    m_TexEnvs:
'''
    maps=[('_BaseMap' if urp else '_MainTex','BaseColor'),('_BumpMap','Normal'),('_MetallicGlossMap','MetallicSmoothness')]
    if name=='WorklightLens':maps.append(('_EmissionMap','Emission'))
    for key,kind in maps:
        text+=f'    - {key}:\n        m_Texture: {tex_ref(name,kind)}\n        m_Scale: {{x: 1, y: 1}}\n        m_Offset: {{x: 0, y: 0}}\n'
    floats={'_BumpScale':.5,'_Metallic':1.,'_Smoothness' if urp else '_Glossiness':1.,'_GlossMapScale':1.,'_SmoothnessTextureChannel':0,'_Cutoff':.5,'_Cull':2,'_ZWrite':1,'_Surface':0,'_AlphaClip':0,'_ReceiveShadows':1}
    text+='    m_Ints: []\n    m_Floats:\n'+''.join(f'    - {k}: {v}\n' for k,v in floats.items())
    text+='    m_Colors:\n    - '+('_BaseColor' if urp else '_Color')+': {r: 1, g: 1, b: 1, a: 1}\n    - _EmissionColor: '+('{r: 1, g: 1, b: 1, a: 1}' if name=='WorklightLens' else '{r: 0, g: 0, b: 0, a: 1}')+'\n  m_BuildTextureStacks: []\n'
    path.write_text(text);meta(path,'NativeFormatImporter:\n  externalObjects: {}\n  mainObjectFileID: 2100000\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n')

def textures():
    for path in (ASSET/'Textures').glob('*.png'):
        normal=path.stem.endswith('_Normal');srgb=path.stem.endswith('_BaseColor') or path.stem.endswith('_Emission');size=1024 if any(k in path.stem for k in ['Graphic','HazardStripes','WorklightLens']) else 512
        meta(path,f'''TextureImporter:
  internalIDToNameTable: []
  externalObjects: {{}}
  serializedVersion: 12
  mipmaps:
    mipMapMode: 0
    enableMipMap: 1
    sRGBTexture: {int(srgb)}
    linearTexture: 0
    fadeOut: 0
    borderMipMap: 0
    mipMapsPreserveCoverage: 0
    alphaTestReferenceValue: 0.5
    mipMapFadeDistanceStart: 1
    mipMapFadeDistanceEnd: 3
  bumpmap:
    convertToNormalMap: 0
    externalNormalMap: {int(normal)}
    heightScale: 0.25
    normalMapFilter: 0
    flipGreenChannel: 0
  isReadable: 0
  streamingMipmaps: 0
  grayScaleToAlpha: 0
  generateCubemap: 6
  cubemapConvolution: 0
  seamlessCubemap: 0
  textureFormat: 1
  maxTextureSize: {size}
  textureSettings:
    serializedVersion: 2
    filterMode: 1
    aniso: 4
    mipBias: 0
    wrapU: 0
    wrapV: 0
    wrapW: 0
  nPOTScale: 0
  lightmap: 0
  compressionQuality: 50
  spriteMode: 0
  alphaUsage: 1
  alphaIsTransparency: 0
  textureType: {1 if normal else 0}
  textureShape: 1
  singleChannelComponent: 0
  flipbookRows: 1
  flipbookColumns: 1
  maxTextureSizeSet: 0
  compressionQualitySet: 0
  textureFormatSet: 0
  ignorePngGamma: 0
  applyGammaDecoding: 0
  platformSettings:
  - serializedVersion: 3
    buildTarget: DefaultTexturePlatform
    maxTextureSize: {size}
    resizeAlgorithm: 0
    textureFormat: -1
    textureCompression: 1
    compressionQuality: 50
    crunchedCompression: 0
    allowsAlphaSplitting: 0
    overridden: 0
    androidETC2FallbackOverride: 0
    forceMaximumCompressionQuality_BC6H_BC7: 0
  userData: 
  assetBundleName: 
  assetBundleVariant: 
''')

def model_meta(p):
    path=ASSET/'Models'/f'CSE_{p["name"]}.fbx'
    meta(path,f'''ModelImporter:
  serializedVersion: 22200
  internalIDToNameTable:
  - first:
      43: 4300000
    second: {p['name']}
  externalObjects: {{}}
  materials:
    materialImportMode: 1
    materialName: 0
    materialSearch: 1
    materialLocation: 1
  animations:
    legacyGenerateAnimations: 4
    bakeSimulation: 0
    resampleCurves: 1
    optimizeGameObjects: 0
    removeConstantScaleCurves: 0
    motionNodeName: 
    rigImportErrors: 
    rigImportWarnings: 
    animationImportErrors: 
    animationImportWarnings: 
    animationRetargetingWarnings: 
    animationDoRetargetingWarnings: 0
    importAnimatedCustomProperties: 0
    importConstraints: 0
    animationCompression: 1
    animationRotationError: 0.5
    animationPositionError: 0.5
    animationScaleError: 0.5
    animationWrapMode: 0
    extraExposedTransformPaths: []
    extraUserProperties: []
    clipAnimations: []
    isReadable: 0
  meshes:
    lODScreenPercentages: []
    globalScale: 1
    meshCompression: 0
    addColliders: 0
    useSRGBMaterialColor: 1
    sortHierarchyByName: 1
    importVisibility: 1
    importBlendShapes: 0
    importCameras: 0
    importLights: 0
    nodeNameCollisionStrategy: 1
    fileIdsGeneration: 2
    swapUVChannels: 0
    generateSecondaryUV: 0
    useFileUnits: 1
    keepQuads: 0
    weldVertices: 1
    bakeAxisConversion: 1
    preserveHierarchy: 0
    skinWeightsMode: 0
    maxBonesPerVertex: 4
    minBoneWeight: 0.001
    optimizeBones: 1
    meshOptimizationFlags: -1
    indexFormat: 0
    secondaryUVAngleDistortion: 8
    secondaryUVAreaDistortion: 15.000001
    secondaryUVHardAngle: 88
    secondaryUVMarginMethod: 1
    secondaryUVMinLightmapResolution: 40
    secondaryUVMinObjectScale: 1
    secondaryUVPackMargin: 4
    useFileScale: 1
  tangentSpace:
    normalSmoothAngle: 60
    normalImportMode: 0
    tangentImportMode: 3
    normalCalculationMode: 4
    legacyComputeAllNormalsFromSmoothingGroupsWhenMeshHasBlendShapes: 0
    blendShapeNormalImportMode: 1
    normalSmoothingSource: 0
  referencedClips: []
  importAnimation: 0
  humanDescription:
    serializedVersion: 3
    human: []
    skeleton: []
    armTwist: 0.5
    foreArmTwist: 0.5
    upperLegTwist: 0.5
    legTwist: 0.5
    armStretch: 0.05
    legStretch: 0.05
    feetSpacing: 0
    globalScale: 1
    rootMotionBoneName: 
    hasTranslationDoF: 0
    hasExtraRoot: 0
    skeletonHasParents: 1
  lastHumanDescriptionAvatarSource: {{instanceID: 0}}
  autoGenerateAvatarMappingIfUnspecified: 1
  animationType: 0
  humanoidOversampling: 1
  avatarSetup: 0
  addHumanoidExtraRootOnlyWhenUsingAvatar: 1
  importBlendShapeDeformPercent: 0
  additionalBone: 0
  userData: 
  assetBundleName: 
  assetBundleVariant: 
''')

def go_base(name,i,components,position=(0,0,0),rotation=(0,0,0,1),scale=(1,1,1)):
    return f'''--- !u!1 &{i}
GameObject:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  serializedVersion: 6
  m_Component:
'''+''.join(f'  - component: {{fileID: {x}}}\n' for x in components)+f'''  m_Layer: 0
  m_Name: {name}
  m_TagString: Untagged
  m_Icon: {{fileID: 0}}
  m_NavMeshLayer: 0
  m_StaticEditorFlags: 0
  m_IsActive: 1
--- !u!4 &{i+1}
Transform:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {i}}}
  serializedVersion: 2
  m_LocalRotation: {quat(rotation)}
  m_LocalPosition: {vec(position)}
  m_LocalScale: {vec(scale)}
  m_ConstrainProportionsScale: 0
  m_Children: []
  m_Father: {{fileID: 0}}
  m_LocalEulerAnglesHint: {{x: 0, y: 0, z: 0}}
'''
def renderer(i,materials):
    return f'''--- !u!23 &{i+3}
MeshRenderer:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {i}}}
  m_Enabled: 1
  m_CastShadows: 1
  m_ReceiveShadows: 1
  m_DynamicOccludee: 1
  m_StaticShadowCaster: 0
  m_MotionVectors: 1
  m_LightProbeUsage: 1
  m_ReflectionProbeUsage: 1
  m_RayTracingMode: 2
  m_RayTraceProcedural: 0
  m_RenderingLayerMask: 1
  m_RendererPriority: 0
  m_Materials:
'''+''.join('  - '+x+'\n' for x in materials)+'''  m_StaticBatchInfo:
    firstSubMesh: 0
    subMeshCount: 0
  m_StaticBatchRoot: {fileID: 0}
  m_ProbeAnchor: {fileID: 0}
  m_LightProbeVolumeOverride: {fileID: 0}
  m_ScaleInLightmap: 1
  m_ReceiveGI: 1
  m_PreserveUVs: 0
  m_IgnoreNormalsForChartDetection: 0
  m_ImportantGI: 0
  m_StitchLightmapSeams: 1
  m_SelectedEditorRenderState: 3
  m_MinimumChartSize: 4
  m_AutoUVMaxDistance: 0.5
  m_AutoUVMaxAngle: 89
  m_LightmapParameters: {fileID: 0}
  m_SortingLayerID: 0
  m_SortingLayer: 0
  m_SortingOrder: 0
  m_AdditionalVertexStreams: {fileID: 0}
'''
def prop_yaml(p,i=100000,position=(0,0,0),rotation=(0,0,0,1)):
    text=go_base('CSE_'+p['name'],i,[i+1,i+2,i+3,i+4],position,rotation)
    text+=f'''--- !u!33 &{i+2}
MeshFilter:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {i}}}
  m_Mesh: {ref_mesh(p)}
'''+renderer(i,[ref_mat(m) for m in p['materials']])+f'''--- !u!64 &{i+4}
MeshCollider:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {i}}}
  m_Material: {{fileID: 0}}
  m_IncludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_ExcludeLayers:
    serializedVersion: 2
    m_Bits: 0
  m_LayerOverridePriority: 0
  m_IsTrigger: 0
  m_ProvidesContacts: 0
  m_Enabled: 1
  serializedVersion: 5
  m_Convex: 0
  m_CookingOptions: 30
  m_Mesh: {ref_mesh(p)}
'''
    return text

def prefab(p):
    path=ASSET/'Prefabs'/f'CSE_{p["name"]}.prefab';path.write_text(HEAD+prop_yaml(p));simplemeta(path,'PrefabImporter')

LAYOUT={'TrafficCone':(-1.25,0,-.7),'SafetyBarrier':(0,0,.9),'HardHat':(-.05,0,-.8),'Wheelbarrow':(.3,0,.03),'Shovel':(-1.0,0,.2),'CementBag':(-.65,0,-.85),'Toolbox':(.55,0,-.95),'RoadSign':(-1.65,0,.75),'PortableWorkLight':(1.55,0,.75),'BrickStack':(-1.8,0,-.95),'RebarBundle':(-.15,0,-1.5),'CautionSign':(1.35,0,-.65)}
def scene():
    text=HEAD+'''--- !u!104 &2
RenderSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 9
  m_Fog: 0
  m_FogColor: {r: 0.5, g: 0.5, b: 0.5, a: 1}
  m_FogMode: 3
  m_FogDensity: 0.01
  m_LinearFogStart: 0
  m_LinearFogEnd: 300
  m_AmbientSkyColor: {r: 0.65, g: 0.68, b: 0.7, a: 1}
  m_AmbientEquatorColor: {r: 0.46, g: 0.48, b: 0.5, a: 1}
  m_AmbientGroundColor: {r: 0.24, g: 0.25, b: 0.26, a: 1}
  m_AmbientIntensity: 1
  m_AmbientMode: 1
  m_SubtractiveShadowColor: {r: 0.42, g: 0.47, b: 0.63, a: 1}
  m_SkyboxMaterial: {fileID: 0}
  m_HaloStrength: 0.5
  m_FlareStrength: 1
  m_FlareFadeSpeed: 3
  m_HaloTexture: {fileID: 0}
  m_SpotCookie: {fileID: 0}
  m_DefaultReflectionMode: 0
  m_DefaultReflectionResolution: 128
  m_ReflectionBounces: 1
  m_ReflectionIntensity: 1
  m_CustomReflection: {fileID: 0}
  m_Sun: {fileID: 90003}
  m_UseRadianceAmbientProbe: 0
'''
    for k,p in enumerate(DATA):text+=prop_yaml(p,100000+k*100,LAYOUT[p['name']])
    # A real serialized demo camera, not a screenshot or inaccessible scene reference.
    position=np.array([4.8,4.5,7.5]);forward=np.array([0,.65,0])-position;forward/=np.linalg.norm(forward);right=np.cross([0,1,0],forward);right/=np.linalg.norm(right);up=np.cross(forward,right);q=Rotation.from_matrix(np.column_stack([right,up,forward])).as_quat()
    text+=go_base('CSE_DemoCamera',80000,[80001,80002],position,q)
    text+='''--- !u!20 &80002
Camera:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  m_GameObject: {fileID: 80000}
  m_Enabled: 1
  serializedVersion: 2
  m_ClearFlags: 2
  m_BackGroundColor: {r: 0.85, g: 0.87, b: 0.85, a: 1}
  m_projectionMatrixMode: 1
  m_GateFitMode: 2
  m_FOVAxisMode: 0
  m_Iso: 200
  m_ShutterSpeed: 0.005
  m_Aperture: 16
  m_FocusDistance: 10
  m_FocalLength: 50
  m_BladeCount: 5
  m_Curvature: {x: 2, y: 11}
  m_BarrelClipping: 0.25
  m_Anamorphism: 0
  m_SensorSize: {x: 36, y: 24}
  m_LensShift: {x: 0, y: 0}
  m_NormalizedViewPortRect:
    serializedVersion: 2
    x: 0
    y: 0
    width: 1
    height: 1
  near clip plane: 0.1
  far clip plane: 100
  field of view: 40
  orthographic: 1
  orthographic size: 2.2
  m_Depth: -1
  m_CullingMask:
    serializedVersion: 2
    m_Bits: 4294967295
  m_RenderingPath: -1
  m_TargetTexture: {fileID: 0}
  m_TargetDisplay: 0
  m_TargetEye: 3
  m_HDR: 1
  m_AllowMSAA: 1
  m_AllowDynamicResolution: 0
  m_ForceIntoRT: 0
  m_OcclusionCulling: 1
  m_StereoConvergence: 10
  m_StereoSeparation: 0.022
'''
    text+=go_base('CSE_KeyLight',90000,[90001,90003],(0,4,0),Rotation.from_euler('xyz',[45,-28,0],degrees=True).as_quat())
    text+='''--- !u!108 &90003
Light:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  m_GameObject: {fileID: 90000}
  m_Enabled: 1
  serializedVersion: 10
  m_Type: 1
  m_Shape: 0
  m_Color: {r: 1, g: 0.97, b: 0.93, a: 1}
  m_Intensity: 1.8
  m_Range: 10
  m_SpotAngle: 30
  m_InnerSpotAngle: 21.80208
  m_CookieSize: 10
  m_Shadows:
    m_Type: 2
    m_Resolution: -1
    m_CustomResolution: -1
    m_Strength: 1
    m_Bias: 0.05
    m_NormalBias: 0.4
    m_NearPlane: 0.2
    m_CullingMatrixOverride:
      e00: 1
      e01: 0
      e02: 0
      e03: 0
      e10: 0
      e11: 1
      e12: 0
      e13: 0
      e20: 0
      e21: 0
      e22: 1
      e23: 0
      e30: 0
      e31: 0
      e32: 0
      e33: 1
    m_UseCullingMatrixOverride: 0
  m_Cookie: {fileID: 0}
  m_DrawHalo: 0
  m_Flare: {fileID: 0}
  m_RenderMode: 0
  m_CullingMask:
    serializedVersion: 2
    m_Bits: 4294967295
  m_RenderingLayerMask: 1
  m_Lightmapping: 4
  m_LightShadowCasterMode: 0
  m_AreaSize: {x: 1, y: 1}
  m_BounceIntensity: 1
  m_ColorTemperature: 6570
  m_UseColorTemperature: 0
  m_BoundingSphereOverride: {x: 0, y: 0, z: 0, w: 0}
  m_UseBoundingSphereOverride: 0
  m_UseViewFrustumForShadowCasterCull: 1
  m_ShadowRadius: 0
  m_ShadowAngle: 0
'''
    path=ASSET/'Demo/CSE_Showcase.unity';path.write_text(text);simplemeta(path)

def generate():
    # FBX files under Models are rewritten with correct local texture paths.
    sys.path.insert(0,str(Path(__file__).resolve().parent));import export_pack
    for p in DATA:
        original=ROOT/'Exports/FBX'/f'CSE_{p["name"]}.fbx'
        # Prefer the Blender-native interchange export when the source bundle
        # has been generated. Unity's FBX importer is stricter than Blender's
        # reader and rejects the small fallback writer's footer/metadata even
        # though Blender can re-import it. Keep the fallback for source-only
        # rebuilds, but use the validated Blender export for delivery assets.
        blender_export=ROOT/'Source/Blender/RegeneratedExports'/original.name
        if blender_export.is_file():
            shutil.copy2(blender_export, original)
            shutil.copy2(blender_export, ASSET/'Models'/original.name)
        else:
            export_pack.fbx(p)
            export_pack.fbx(p, ASSET/'Models'/original.name, '../Textures/')
        model_meta(p)
    for pipe in ['URP','BuiltIn']:
        for name,spec in MATS.items():material(name,pipe,spec)
    textures()
    for p in DATA:prefab(p)
    scene()
    manifest={'version':'1.0.0','materials':[dict(name=k,**v) for k,v in MATS.items()],'props':[{'name':p['name'],'materials':p['materials'],'triangles':p['stats']['triangles'],'dimensions':p['stats']['dimensions_xyz_m'],'demoPosition':list(LAYOUT[p['name']])} for p in DATA]}
    path=ASSET/'Editor/CSEManifest.json';path.write_text(json.dumps(manifest,indent=2));simplemeta(path,'TextScriptImporter')
    for path in sorted([p for p in ASSET.rglob('*') if p.is_dir()]):meta(path,'DefaultImporter:\n  externalObjects: {}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n',True)
    print('UNITY_ASSETS_GENERATED',flush=True)
if __name__=='__main__':generate()
