"""Create clean, editable Blender source from the delivered original mesh data.
Run: blender --background --python Source/build_blender.py
Optional: -- --render (also renders the showcase using Blender).
This script is supplied as the Blender-source reconstruction path.  The
delivery was executed with Blender 5.1.2 and the saved source plus native
interchange exports are included; rerun it with Blender 4.2+ when regenerating
from source.  Only Blender's bundled Python modules are used.
"""
from __future__ import annotations
import argparse,json,math,sys
from pathlib import Path
import bpy
from mathutils import Vector
ROOT=Path(__file__).resolve().parent.parent
DATA=json.loads((ROOT/'Source/mesh_data.json').read_text())
SPECS=json.loads((ROOT/'Source/materials.json').read_text())
TEXTURES=ROOT/'UnityProject/Assets/ConstructionSiteEssentials/Textures'
OUT=ROOT/'Source/Blender';OUT.mkdir(parents=True,exist_ok=True)
MATERIALS={}

def make_material(name,spec):
    mat=bpy.data.materials.new('CSE_'+name);mat.use_nodes=True;mat.use_backface_culling=True
    nodes=mat.node_tree.nodes;links=mat.node_tree.links;bsdf=nodes.get('Principled BSDF');bsdf.inputs['Metallic'].default_value=spec['metallic'];bsdf.inputs['Roughness'].default_value=spec['roughness']
    def image_node(suffix,non_color=False,location=(0,0)):
        node=nodes.new('ShaderNodeTexImage');node.label=suffix;node.name='CSE_'+suffix;node.location=location
        image=bpy.data.images.load(str(TEXTURES/f'CSE_{name}_{suffix}.png'),check_existing=True)
        if non_color:image.colorspace_settings.name='Non-Color'
        node.image=image;node.interpolation='Linear';node.extension='REPEAT';return node
    albedo=image_node('BaseColor',False,(-650,260));links.new(albedo.outputs['Color'],bsdf.inputs['Base Color'])
    orm=image_node('ORM',True,(-650,0));separate=nodes.new('ShaderNodeSeparateColor');separate.location=(-380,0);links.new(orm.outputs['Color'],separate.inputs['Color']);links.new(separate.outputs['Green'],bsdf.inputs['Roughness']);links.new(separate.outputs['Blue'],bsdf.inputs['Metallic'])
    normal=image_node('Normal',True,(-650,-260));normalmap=nodes.new('ShaderNodeNormalMap');normalmap.location=(-370,-250);normalmap.inputs['Strength'].default_value=.5;links.new(normal.outputs['Color'],normalmap.inputs['Color']);links.new(normalmap.outputs['Normal'],bsdf.inputs['Normal'])
    if name=='WorklightLens':
        em=image_node('Emission',False,(-650,-480));slot='Emission Color' if 'Emission Color' in bsdf.inputs else 'Emission';links.new(em.outputs['Color'],bsdf.inputs[slot])
        if 'Emission Strength' in bsdf.inputs:bsdf.inputs['Emission Strength'].default_value=1.
    return mat

def uv_layers(mesh,faces,uv0,uv1):
    a=mesh.uv_layers.new(name='UVMap');b=mesh.uv_layers.new(name='LightmapUV')
    for poly,face in zip(mesh.polygons,faces):
        for loop,vertex in zip(poly.loop_indices,face):a.data[loop].uv=uv0[vertex];b.data[loop].uv=uv1[vertex]
    mesh.uv_layers.active_index=0;a.active_render=True

def build():
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    for c in list(bpy.data.collections):
        if c.users==0:bpy.data.collections.remove(c)
    scene=bpy.context.scene;scene.name='CSE_Editable_Source';scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1.0
    source_coll=bpy.data.collections.new('01_Editable_Prop_Parts');scene.collection.children.link(source_coll)
    runtime_coll=bpy.data.collections.new('02_Combined_Export_Meshes');scene.collection.children.link(runtime_coll)
    for name,spec in SPECS.items():MATERIALS[name]=make_material(name,spec)
    runtime=[]
    for index,p in enumerate(DATA):
        group=bpy.data.collections.new(f'{index+1:02d}_{p["name"]}');source_coll.children.link(group)
        parent=bpy.data.objects.new('CSE_'+p['name']+'_SOURCE',None);group.objects.link(parent);parent.location=((index%4-1.5)*2.5,(index//4-1)*2.5,0);parent.empty_display_size=.12
        cursor=0
        for k,part in enumerate(p['source']):
            mesh=bpy.data.meshes.new(f'{p["name"]}_{k+1:03d}_{part["name"]}');mesh.from_pydata(part['vertices'],[],part['faces']);mesh.update()
            mesh.materials.append(MATERIALS[part['material']]);obj=bpy.data.objects.new(mesh.name,mesh);group.objects.link(obj);obj.parent=parent
            for poly in mesh.polygons:poly.use_smooth=part['smooth']
            a=mesh.uv_layers.new(name='UVMap');b=mesh.uv_layers.new(name='LightmapUV')
            for localface,poly in enumerate(mesh.polygons):
                globalface=p['faces'][cursor+localface]
                for li,vi in zip(poly.loop_indices,globalface):a.data[li].uv=p['uv0'][vi];b.data[li].uv=p['uv1'][vi]
            cursor+=len(part['faces']);mesh.uv_layers.active_index=0;a.active_render=True
            if part['smooth'] and hasattr(mesh,'normals_split_custom_set_from_vertices'):mesh.normals_split_custom_set_from_vertices(part['normals'])
            obj['component']=part['name'];obj['units']='metres';obj['original_procedural_asset']=True
        mesh=bpy.data.meshes.new('CSE_'+p['name']);mesh.from_pydata(p['vertices'],[],p['triangles']);mesh.update()
        for name in p['materials']:mesh.materials.append(MATERIALS[name])
        for poly,mi in zip(mesh.polygons,p['tri_material']):poly.material_index=mi;poly.use_smooth=True
        uv_layers(mesh,p['triangles'],p['uv0'],p['uv1'])
        if hasattr(mesh,'normals_split_custom_set_from_vertices'):mesh.normals_split_custom_set_from_vertices(p['normals'])
        obj=bpy.data.objects.new('CSE_'+p['name'],mesh);runtime_coll.objects.link(obj);obj.location=parent.location;obj['triangle_count']=p['stats']['triangles'];obj['description']=p['notes'];obj['pivot']='bottom centre';obj.asset_mark();obj.asset_data.description=p['notes'];runtime.append(obj)
    # Hide combined duplicate meshes in the source scene, not the editable parts.
    runtime_coll.hide_render=True;runtime_coll.hide_viewport=True
    scene.world=bpy.data.worlds.new('CSE_Neutral_Studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.25,.25,.25,1)
    scene.render.engine='CYCLES';scene.cycles.samples=32
    readme=bpy.data.texts.new('START_HERE');readme.write('Construction Site Essentials\n12 original props. One Blender unit = one metre.\n01_Editable_Prop_Parts contains named component meshes.\n02_Combined_Export_Meshes contains the matching combined game meshes (hidden to avoid duplicates).\nUVMap repeats reusable materials intentionally. LightmapUV is uniquely packed.\nNo rig, animation or LOD variants. See the ZIP README and validation checklist.\n')
    # Save the editable source before optional regeneration of interchange exports.
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'ConstructionSiteEssentials.blend'))
    # Export only the combined meshes, one at the origin at a time.
    runtime_coll.hide_viewport=False;runtime_coll.hide_render=False;source_coll.hide_render=True
    export_dir=OUT/'RegeneratedExports';export_dir.mkdir(exist_ok=True)
    for obj in runtime:
        bpy.ops.object.select_all(action='DESELECT');obj.hide_set(False);obj.select_set(True);bpy.context.view_layer.objects.active=obj
        saved=obj.location.copy();obj.location=(0,0,0)
        try:
            bpy.ops.export_scene.gltf(filepath=str(export_dir/(obj.name+'.glb')),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
            bpy.ops.export_scene.fbx(filepath=str(export_dir/(obj.name+'.fbx')),use_selection=True,object_types={'MESH'},global_scale=1,apply_unit_scale=True,axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',add_leaf_bones=False,bake_anim=False,path_mode='AUTO')
        finally:obj.location=saved
    runtime_coll.hide_viewport=True;runtime_coll.hide_render=True;source_coll.hide_render=False
    bpy.ops.object.select_all(action='DESELECT');bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'ConstructionSiteEssentials.blend'))
    print('CSE: saved',OUT/'ConstructionSiteEssentials.blend')
    return scene,source_coll,runtime_coll,runtime

def render_showcase(source,combined,objects):
    source.hide_render=True;combined.hide_render=False;combined.hide_viewport=False
    layout={'TrafficCone':((-1.25,-.7,0),0),'SafetyBarrier':((0,.9,0),0),'HardHat':((-.05,-.8,0),0),'Wheelbarrow':((.3,.03,0),-23),'Shovel':((-1,.2,0),-8),'CementBag':((-.65,-.85,0),10),'Toolbox':((.55,-.95,0),-8),'RoadSign':((-1.65,.75,0),-12),'PortableWorkLight':((1.55,.75,0),-13),'BrickStack':((-1.8,-.95,0),-15),'RebarBundle':((-.15,-1.5,0),-5),'CautionSign':((1.35,-.65,0),-13)}
    for obj in objects:
        pos,a=layout[obj.name.replace('CSE_','',1)];obj.location=pos;obj.rotation_euler.z=math.radians(a)
    bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.003));floor=bpy.context.object;floor.name='DEMO_ONLY_StudioFloor';mat=bpy.data.materials.new('DEMO_ONLY_NeutralFloor');mat.diffuse_color=(.65,.67,.65,1);floor.data.materials.append(mat)
    for name,pos,power,size in [('Key',(-3,-4,6),1200,5),('Fill',(4,-1,4),850,4),('Rim',(0,4,5),1500,3)]:
        data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;obj=bpy.data.objects.new(name,data);bpy.context.scene.collection.objects.link(obj);obj.location=pos;obj.rotation_euler=(Vector((0,0,.6))-obj.location).to_track_quat('-Z','Y').to_euler()
    data=bpy.data.cameras.new('CSE_Camera');cam=bpy.data.objects.new('CSE_Camera',data);bpy.context.scene.collection.objects.link(cam);cam.location=(4.9,-8.5,5.5);cam.rotation_euler=(Vector((0,-.13,.65))-cam.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=5.8;bpy.context.scene.camera=cam
    scene=bpy.context.scene;scene.render.resolution_x=2200;scene.render.resolution_y=1450;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath=str(OUT/'Blender_Showcase.png');bpy.ops.render.render(write_still=True)

if __name__=='__main__':
    args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    parser=argparse.ArgumentParser();parser.add_argument('--render',action='store_true');ns=parser.parse_args(args)
    _,source,combined,objects=build()
    if ns.render:render_showcase(source,combined,objects)
