# Editable source and reproducible build

## Blender source (no external Python dependencies)

Run `blender --background --python Source/build_blender.py` from the extracted delivery root. The script resolves its data paths relative to itself, not the working directory. Intended for Blender 4.2+. The Blender script was Python syntax checked only because Blender was unavailable here.

The included saved file was generated and inspected with Blender 5.1.2. The source script remains reproducible on Blender 4.2+; rerun it after changing Blender versions. The saved file contains:

- `01_Editable_Prop_Parts`: 12 named prop groups with logical component meshes, original quads/ngons, materials and both UV layers. The showcase grid offsets are stored on parent empties, not baked into individual component vertices.
- `02_Combined_Export_Meshes`: 12 matching triangulated meshes, hidden in the editable scene to avoid duplicates. They are marked as Blender assets and retain ground-centre pivots.
- Packed original images, Principled BSDF node networks, metric units and a START_HERE text block.

The file is saved before native Blender exports are requested. If an exporter version changes an API, the already saved source remains available for manual export. Inspect modifiers, normals, materials, axes and texture links before replacing the supplied interchange files with regenerated versions. The source script clears the active scene; run it in a disposable Blender session.

## Authoring data

`Source/mesh_data.json` is the canonical delivered component and runtime mesh data. For each of the twelve props it stores original named component vertices/faces/materials, smooth normals, the matching combined vertices/triangles, material assignments, UV0, UV1, dimensions and counts. This is editable geometry, not a reference to a remote model.

`Source/materials.json` describes reusable surface colors, metallic values and roughness settings. Textures are local files in the Unity asset root. The original code is deterministic; no model/texture downloads are performed.

## Regenerate outside Blender (advanced)

The build workspace used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, Pillow 12.3.0, Trimesh 4.11.1 VTK 9.6.2 and PyYAML 6.0.3. These libraries are tools, not bundled dependencies for using the assets in a game. VTK offscreen rendering requires a compatible graphics/EGL environment. Other versions/platforms are not verified.

After creating an isolated Python environment and installing `Source/requirements-source.txt`, run from the delivery root:

```sh
python Source/author_pack.py
python Source/export_pack.py
python Source/build_unity_scaffold.py
python Source/render_previews.py all
python Source/compose_previews.py
python Validation/validate_pack.py
```

These commands overwrite generated geometry/textures/exports/scaffold/previews inside this pack. Back up custom edits first. `author_pack.py` retains all custom primitive/assembly definitions and noise/graphic algorithms; `export_pack.py` is the original GLB/FBX writer; `build_unity_scaffold.py` creates deterministic materials/prefabs/scene metadata, not a substitute for Unity Editor serialization tests. Preview composition looks for a locally installed DejaVu Sans font for typography only; no font file is delivered. Adjust the two font-path constants on other operating systems.

Running those generation steps is not required to use the included binaries. The independent Unity Editor setup/validation path is described in the main README. The final archive/manifest assembler is also provided as `Source/package_delivery.py`; it can regenerate the source bundle, metadata, inventory and delivery archives after edits.

## Source bundle inside the Unity package

`Assets/ConstructionSiteEssentials/Source/ConstructionSiteEssentials_source.zip` contains the source scripts/data, validator and source notes. Extract that bundle to a new working folder and copy the installed package's Textures folder to the relative location described in its START_HERE.txt before running Blender. This avoids putting non-Unity Python scripts into Unity's code compilation folders. The external delivery already has the complete ready-to-resolve folder layout.
